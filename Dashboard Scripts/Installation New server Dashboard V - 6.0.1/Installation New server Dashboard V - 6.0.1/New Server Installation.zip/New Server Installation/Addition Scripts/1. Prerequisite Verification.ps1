﻿# ==============================================================================
# --- APPEND THIS COMPREHENSIVE BLOCK TO THE END OF YOUR BASE SCRIPT ---
# ==============================================================================

# --- [PHASE 2] CONFIGURE BI-DIRECTIONAL FIREWALL (SILENT FAST RAM CHECK) ---
if (Get-Command "Write-Log" -ErrorAction SilentlyContinue) {
    Write-Log "`n--- Configuring Firewall Ports (Inbound & Outbound) ---"
}

$requiredPorts = @(80, 443, 8888, 8889, 8080, 6666, 6667, 8245, 7005, 6990, 9998, 8090, 3000, 5555, 9600, 1433, 8081, 8182, 8181)
$directions = @("Inbound", "Outbound")

# Read current rules into memory once to eliminate processing lag completely
$existingRules = Get-NetFirewallRule -ErrorAction SilentlyContinue | Select-Object -ExpandProperty DisplayName

foreach ($port in $requiredPorts) {
    foreach ($direction in $directions) {
        $ruleName = "ProPhoenix Port $port ($direction)"
        
        if ($existingRules -notcontains $ruleName) {
            try {
                New-NetFirewallRule -DisplayName $ruleName `
                                    -Direction $direction `
                                    -Action Allow `
                                    -Protocol TCP `
                                    -LocalPort $port `
                                    -Profile Any -ErrorAction Stop | Out-Null
            } catch {
                Write-Warning "Failed to auto-configure firewall rule for port $port ($direction)"
            }
        }
    }
}

# --- [PHASE 3] DETAILED ENVIRONMENT VERIFICATION AUDIT ---
Write-Host "`n==========================================================" -ForegroundColor Cyan
Write-Host "           DETAILED STEP-BY-STEP INSTALLATION AUDIT" -ForegroundColor Cyan
Write-Host "==========================================================" -ForegroundColor Cyan

# Gather complete local inventory string values to prevent character truncation
$inventory = Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*", "HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*" -ErrorAction SilentlyContinue

# --- [STEP 1] FIPS COMPLIANCE ---
Write-Host "`n[STEP 1] FIPS Compliance Check" -ForegroundColor Yellow
$fips = (Get-ItemProperty -Path "HKLM:\System\CurrentControlSet\Control\Lsa\FipsAlgorithmPolicy" -Name "Enabled" -ErrorAction SilentlyContinue).Enabled
if ($fips -eq 1) { 
    Write-Host "  [SUCCESS] FIPS is ENABLED in registry." -ForegroundColor Green 
} else {
    Write-Host "  [FAILURE] FIPS is NOT enabled." -ForegroundColor Red
}

# --- [STEP 2] PREREQUISITE SOFTWARE ---
Write-Host "`n[STEP 2] Prerequisite Software Check" -ForegroundColor Yellow
$appsToCheck = @(
    @{ Key="SAP Crystal Reports runtime"; Search="SAP Crystal Reports runtime" },
    @{ Key="Server Application Manager"; Search="Server Application Manager" },
    @{ Key="Client Application Manager"; Search="Client Application Manager" },
    @{ Key="Adobe Reader"; Search="Adobe Reader" },
    @{ Key="ASP.NET Core 8.0"; Search="ASP.NET Core 8.0" },
    @{ Key="Access database engine"; Search="Access database engine" },
    @{ Key="SmartInspect"; Search="SmartInspect" },
    @{ Key="WebView2 Runtime"; Search="WebView2" },
    @{ Key="SQL Server System CLR Types"; Search="System CLR Types for SQL Server" }, 
    @{ Key="Report Viewer"; Search="Report Viewer" },
    @{ Key="OLE DB Driver"; Search="OLE DB Driver" }
)

foreach ($app in $appsToCheck) {
    $matches = $inventory | Where-Object { $_.DisplayName -like "*$($app.Search)*" }
    if ($matches) {
        foreach ($m in $matches) {
            Write-Host "  [SUCCESS] Found: $($m.DisplayName)" -ForegroundColor Green
            Write-Host "            Version: $($m.DisplayVersion)" -ForegroundColor Gray
        }
    } else {
        Write-Host "  [FAILURE] MISSING: $($app.Key)" -ForegroundColor Red
    }
}

# --- [STEP 3] MACHINE.CONFIG VALIDATION ---
Write-Host "`n[STEP 3] .NET Machine.config XML Structure Audit" -ForegroundColor Yellow
$configs = @(
    "C:\Windows\Microsoft.NET\Framework\v2.0.50727\Config\machine.config",
    "C:\Windows\Microsoft.NET\Framework64\v2.0.50727\Config\machine.config",
    "C:\Windows\Microsoft.NET\Framework\v4.0.30319\Config\machine.config",
    "C:\Windows\Microsoft.NET\Framework64\v4.0.30319\Config\machine.config"
)
foreach ($path in $configs) {
    if (Test-Path $path) {
        try {
            [xml]$xml = Get-Content $path -ErrorAction SilentlyContinue
            $node = $xml.SelectSingleNode("//processModel[@autoConfig='false']")
            if ($node) { 
                Write-Host "  [SUCCESS] Optimization verified: $path" -ForegroundColor Green 
            } else { 
                Write-Host "  [FAILURE] Optimization missing or incorrect in: $path" -ForegroundColor Red 
            }
        } catch {
            Write-Host "  [ERROR] Failed parsing XML file: $path" -ForegroundColor Red
        }
    } else { 
        Write-Host "  [SKIP] Path not found: $path" -ForegroundColor Gray 
    }
}

# --- [STEP 4] PAGEFILE STRUCTURAL EVALUATION ---
Write-Host "`n[STEP 4] Windows Virtual Memory Pagefile Allocation Audit" -ForegroundColor Yellow
try {
    $pagingFiles = (Get-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management' -Name 'PagingFiles' -ErrorAction SilentlyContinue).PagingFiles
    if ($pagingFiles) {
        Write-Host "  [SUCCESS] Active Paging Configuration Verified: $pagingFiles" -ForegroundColor Green
    } else {
        Write-Host "  [FAILURE] Page file settings are NOT configured as desired." -ForegroundColor Red
    }
} catch {
    Write-Host "  [ERROR] Failed to query pagefile memory registry attributes." -ForegroundColor Red
}

# --- [STEP 5] FIREWALL COMPLIANCE SUMMARY ---
Write-Host "`n[STEP 5] ProPhoenix Firewall Rules Audit" -ForegroundColor Yellow

$freshRules = Get-NetFirewallRule -ErrorAction SilentlyContinue | Select-Object -ExpandProperty DisplayName
$missingRules = @()

foreach ($port in $requiredPorts) {
    foreach ($direction in $directions) {
        $ruleName = "ProPhoenix Port $port ($direction)"
        if ($freshRules -notcontains $ruleName) {
            $missingRules += "Port $port ($direction)"
        }
    }
}

if ($missingRules.Count -eq 0) {
    Write-Host "  [SUCCESS] Firewall is fully configured." -ForegroundColor Green
} else {
    Write-Host "  [FAILURE] Firewall is NOT fully configured." -ForegroundColor Red
    foreach ($missing in $missingRules) {
        Write-Host "    -> Missing: $missing" -ForegroundColor Yellow
    }
}

# --- [STEP 6] INFRASTRUCTURE & MAINTENANCE POLICY ---
Write-Host "`n[STEP 6] Infrastructure & Automation System Policy Check" -ForegroundColor Yellow

$task = Get-ScheduledTask -TaskName "Clean Logs in IIS" -ErrorAction SilentlyContinue
if ($task) { 
    Write-Host "  [SUCCESS] IIS Log Cleaner Task Registered." -ForegroundColor Green 
    Write-Host "            Current Status: $($task.State)" -ForegroundColor Gray
} else { 
    Write-Host "  [FAILURE] Log Cleaner Automation Task not found." -ForegroundColor Red 
}

$logCleanerPath = "${installDrive}:\PnxTemp\LogCleaner\CleanLogs.bat"
if (Test-Path $logCleanerPath) {
    Write-Host "  [SUCCESS] Log Cleaner script active at location: $logCleanerPath" -ForegroundColor Green
}

$au = (Get-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU" -Name "AUOptions" -ErrorAction SilentlyContinue).AUOptions
if ($au -eq 3) { 
    Write-Host "  [SUCCESS] SConfig Update Policy: Download Only Verified." -ForegroundColor Green 
} else {
    Write-Host "  [FAILURE] SConfig Update Policy Incorrect (Value: $au)." -ForegroundColor Red
}

# --- [STEP 7] IIS FEATURES & ROLES GLOBAL AUDIT ---
Write-Host "`n[STEP 7] Global IIS Features & Server Roles Audit" -ForegroundColor Yellow

# Corrected feature mapping names to precisely match Windows Server internal names
$iisFeatures = @(
    @{ Name="Web-Server"; Desc="IIS Base Engine" },
    @{ Name="Web-Static-Content"; Desc="Common HTTP Features: Static Content" },
    @{ Name="Web-Default-Doc"; Desc="Common HTTP Features: Default Document" },
    @{ Name="Web-Dir-Browsing"; Desc="Common HTTP Features: Directory Browsing" },
    @{ Name="Web-Http-Errors"; Desc="Common HTTP Features: HTTP Errors" },
    @{ Name="Web-Http-Redirect"; Desc="Common HTTP Features: HTTP Redirection" },
    @{ Name="Web-Asp-Net45"; Desc="Application Development: ASP.NET 4.5/4.8" },
    @{ Name="Web-Net-Ext45"; Desc="Application Development: .NET Extensibility" },
    @{ Name="Web-CGI"; Desc="Application Development: CGI" },
    @{ Name="Web-ISAPI-Ext"; Desc="Application Development: ISAPI Extensions" },
    @{ Name="Web-ISAPI-Filter"; Desc="Application Development: ISAPI Filters" },
    @{ Name="Web-Http-Logging"; Desc="Health and Diagnostics: HTTP Logging" },
    @{ Name="Web-Log-Libraries"; Desc="Health and Diagnostics: Logging Tools" },
    @{ Name="Web-Request-Monitor"; Desc="Health and Diagnostics: Request Monitor" },
    @{ Name="Web-Http-Tracing"; Desc="Health and Diagnostics: Tracing" },
    @{ Name="Web-Basic-Auth"; Desc="Security: Basic Authentication" },
    @{ Name="Web-Windows-Auth"; Desc="Security: Windows Authentication" },
    @{ Name="Web-Digest-Auth"; Desc="Security: Digest Authentication" },
    @{ Name="Web-Stat-Compression"; Desc="Performance: Static Content Compression" },
    @{ Name="Web-Dyn-Compression"; Desc="Performance: Dynamic Content Compression" },
    @{ Name="Web-Mgmt-Console"; Desc="Management Tools: IIS Management Console" },
    @{ Name="Web-Metabase"; Desc="IIS 6 Compatibility: IIS 6 Metabase Compatibility" }, # Fixed: Corrected from Web-Lgcy-Metabase
    @{ Name="Web-WMI"; Desc="IIS 6 Compatibility: IIS 6 WMI Compatibility" },
    @{ Name="Web-Lgcy-Mgmt-Console"; Desc="IIS 6 Compatibility: IIS 6 Management Console" },
    @{ Name="Web-Ftp-Server"; Desc="FTP Server Engine" } # Fixed: Corrected from FTP-Server
)

try {
    Import-Module ServerManager -ErrorAction SilentlyContinue
    # Fetching fresh system features to evaluate installation state
    $systemFeatures = Get-WindowsFeature

    $missingFeaturesCount = 0
    foreach ($feature in $iisFeatures) {
        $currentStatus = $systemFeatures | Where-Object { $_.Name -eq $feature.Name }
        if ($currentStatus -and $currentStatus.Installed) {
            Write-Host "  [SUCCESS] Installed: $($feature.Desc)" -ForegroundColor Green
        } else {
            Write-Host "  [FAILURE] MISSING ROLE: $($feature.Desc) ($($feature.Name))" -ForegroundColor Red
            $missingFeaturesCount++
        }
    }

    Write-Host "`n----------------------------------------------------------" -ForegroundColor Gray
    if ($missingFeaturesCount -eq 0) {
        Write-Host "  -> Global Environment Check: IIS is fully optimized for all production environments." -ForegroundColor Green
    } else {
        Write-Host "  -> Global Environment Check: $missingFeaturesCount required IIS roles are missing." -ForegroundColor Yellow
        Write-Host "     Run: 'Install-WindowsFeature <Feature-Name>' to resolve omissions." -ForegroundColor Gray
    }
} catch {
    Write-Host "  [ERROR] ServerManager module is unavailable. Skipping structural IIS role query." -ForegroundColor Red
}

Write-Host "`n==========================================================" -ForegroundColor Cyan
Write-Host "                 AUDIT COMPLETE" -ForegroundColor Cyan
Write-Host "==========================================================" -ForegroundColor Cyan


# --- Add these two lines here ---
Write-Host "`nScript execution is complete." -ForegroundColor Cyan

Read-Host -Prompt "Press Enter to close the terminal"
[Environment]::Exit(0)