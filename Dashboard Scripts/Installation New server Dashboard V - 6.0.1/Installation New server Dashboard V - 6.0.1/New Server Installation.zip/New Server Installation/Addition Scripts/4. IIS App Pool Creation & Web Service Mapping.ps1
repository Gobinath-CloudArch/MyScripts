﻿# Requires elevated privileges (Run as Administrator)

# --- Ensure Administrator Privileges ---
$isAdmin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
if (-not $isAdmin) {
    Write-Host "❌ ERROR: This script must be run as Administrator." -ForegroundColor Red
    Pause
    exit
}

# --- Server Selection Prompt ---
Write-Host "`n========================================" -ForegroundColor Cyan
Write-Host "  PROPHOENIX IIS PROVISIONING MENU" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "Which server do you want to provision the app pool for?"
Write-Host "  1 - RMS Server"
Write-Host "  2 - CAD Server"
Write-Host "  3 - Test Server (All Applications)"
Write-Host "========================================" -ForegroundColor Cyan

$serverChoice = Read-Host "Enter your choice (1, 2, or 3)"

# Define which apps belong to which server profile
$rmsApps = @("Law", "Fire", "IA", "ADR", "NIBRSService", "KGIS", "ProvisionManager", "Webservice", "FireWS", "PhoenixPDFService", "PnxDiagram", "PnxDiagramAPI", "UserDocs", "PhoenixInspectionAPI")
$cadApps = @("WDAApp", "WDAV2API")

# --- Configuration Variables ---
$LogPath = "C:\Scripts\IIS_Config_Log.txt"

# Master lists for special pool configurations (kept intact for reference)
$noManagedCodeAppPools = @("WDAV2API", "PnxDiagram", "PnxDiagramAPI", "PhoenixInspectionAPI")
$advancedSettingsPools = @("PhoenixPolice", "PhoenixFire", "PhoenixIA")
$specialRMSPool = "PhoenixPolice"
$appCmdPath = "$env:windir\system32\inetsrv\appcmd.exe"
$DEFAULT_SITE = "Default Web Site"

# Master list of all possible applications
$masterApplications = @{
    "Law"                  = "PhoenixPolice";
    "Fire"                 = "PhoenixFire";
    "IA"                   = "PhoenixIA";
    "ADR"                  = "ADR";
    "NIBRSService"         = "NIBRS";
    "PnxRptSvr"            = "PnxRptSvr";
    "KGIS"                 = "KGISPD";
    "ProvisionManager"     = "ProvisionManager";
    "Webservice"           = "Webservice";
    "FireWS"               = "FireWS";
    "WDAApp"               = "WDAApp";
    "PhoenixPDFService"    = "PhoenixPDFService";
    "PnxDiagram"           = "PnxDiagram";
    "PnxDiagramAPI"        = "PnxDiagramAPI";
    "UserDocs"             = "UserDocs";
    "WDAV2API"             = "WDAV2API"
    "PhoenixInspectionAPI" = "PhoenixInspectionAPI"
}

# --- Filter Applications Based on User Choice ---
$applications = @{}

if ($serverChoice -eq '1') {
    Write-Host "`n-> Selected: RMS Server Profile" -ForegroundColor Yellow
    foreach ($app in $rmsApps) { 
        if ($masterApplications.ContainsKey($app)) { $applications[$app] = $masterApplications[$app] } 
    }
} elseif ($serverChoice -eq '2') {
    Write-Host "`n-> Selected: CAD Server Profile" -ForegroundColor Yellow
    foreach ($app in $cadApps) { 
        if ($masterApplications.ContainsKey($app)) { $applications[$app] = $masterApplications[$app] } 
    }
} elseif ($serverChoice -eq '3') {
    Write-Host "`n-> Selected: Test Server Profile (All Applications)" -ForegroundColor Yellow
    $applications = $masterApplications
} else {
    Write-Host "❌ Invalid choice. Exiting script." -ForegroundColor Red
    Pause
    exit
}

# Generate the unique list of App Pools we actually need to create based on the filtered apps
$targetAppPools = $applications.Values | Select-Object -Unique

# --- Functions ---

function Test-AppPoolExists {
    param ([string]$Name)
    $result = & $appCmdPath list apppool /name:"$Name" /text:name 2>$null
    return -not [string]::IsNullOrEmpty($result)
}

function New-ApplicationPool {
    param ([string]$Name)
    if (Test-AppPoolExists -Name $Name) { 
        Write-Output "App Pool '$Name' already exists. Skipping creation."
        return $true 
    }
    Write-Host "Creating application pool '$Name'..." -ForegroundColor Cyan
    try {
        & $appCmdPath add apppool /name:"$Name" | Out-Null
        return $true
    } catch {
        Write-Error "Failed to create application pool '$Name': $($_.Exception.Message)"
        return $false
    }
}

function Set-AppPoolProperty {
    param (
        [string]$Name,
        [string]$Property,
        [string]$Value
    )
    try {
        & $appCmdPath set apppool /apppool.name:"$Name" /"$Property":"$Value" | Out-Null
        Write-Output "Successfully set $Property to $Value for $Name"
    } catch {
        Write-Warning "Failed to set $Property for $Name"
    }
}

function Set-ServiceRecovery {
    param ([string]$ServiceName)
    Write-Output "Configuring recovery for: $ServiceName"
    # Reset fail count after 1 day (86400s), restart after 1 min (60000ms)
    $scCmd = "sc.exe failure `"$ServiceName`" reset= 86400 actions= restart/60000/restart/60000/restart/60000"
    Invoke-Expression $scCmd | Out-Null
}

# --- Main Script Execution ---

# Ensure log directory exists
$logDir = Split-Path $LogPath
if (-not (Test-Path $logDir)) { New-Item -ItemType Directory -Force -Path $logDir | Out-Null }

Start-Transcript -Path $LogPath -Append
Write-Host "--- Starting Configuration at $(Get-Date) ---" -ForegroundColor Green

Import-Module WebAdministration -ErrorAction SilentlyContinue

# 1. Process Target Application Pools
foreach ($pool in $targetAppPools) {
    if (New-ApplicationPool -Name $pool) {
        Set-AppPoolProperty -Name $pool -Property "processModel.identityType" -Value "NetworkService"
        Set-AppPoolProperty -Name $pool -Property "enable32BitAppOnWin64" -Value "false"
        
        # Managed Code Logic
        $runtime = if ($noManagedCodeAppPools -contains $pool) { "" } else { "v4.0" }
        Set-AppPoolProperty -Name $pool -Property "managedRuntimeVersion" -Value $runtime

        # Idle Action Suspend
        if ($advancedSettingsPools -contains $pool) {
            Set-AppPoolProperty -Name $pool -Property "processModel.idleTimeoutAction" -Value "Suspend"
        }

        # Rapid Fail Protection
        if ($pool -eq $specialRMSPool) {
            Set-AppPoolProperty -Name $pool -Property "failure.rapidFailProtection" -Value "false"
        }
    }
}

# 2. Map Applications to Pools
foreach ($app in $applications.Keys) {
    $pool = $applications[$app]
    try {
        & $appCmdPath set app /app.name:"$DEFAULT_SITE/$app" /applicationPool:"$pool" | Out-Null
        Write-Host "Mapped $app to $pool" -ForegroundColor Gray
    } catch {
        Write-Warning "Could not map $app. Ensure the virtual directory exists."
    }
}

# 3. Specialized PDF Service Fix (Only if the pool was actually created)
if ($targetAppPools -contains "PhoenixPDFService") {
    Write-Host "Applying stability fix to PhoenixPDFService..."
    try {
        Set-ItemProperty "IIS:\AppPools\PhoenixPDFService" -Name "processModel.idleTimeout" -Value "00:20:00" -ErrorAction Stop
        Set-ItemProperty "IIS:\AppPools\PhoenixPDFService" -Name "recycling.periodicRestart.time" -Value "1.00:00:00" -ErrorAction Stop
    } catch {
        Write-Warning "Failed to set PhoenixPDFService stability fixes. Is the IIS module loaded?"
    }
}

# 4. Service Recovery (Applies globally regardless of profile)
Get-Service -Name "Phoenix*", "aspnet_state" -ErrorAction SilentlyContinue | ForEach-Object {
    Set-ServiceRecovery -ServiceName $_.Name
}

Write-Host "--- Configuration Complete. Log saved to $LogPath ---" -ForegroundColor Green
Stop-Transcript

Write-Host "`nScript has finished running!" -ForegroundColor Cyan

Read-Host -Prompt "Press Enter to close the terminal"
[Environment]::Exit(0)