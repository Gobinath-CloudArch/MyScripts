# ==============================================================================
# PROPHOENIX AUTO-CONFIGURATION SCRIPT
# ==============================================================================
 
# ==============================================================================
# HOW TO EDIT CONFIGURATIONS
# ==============================================================================
# Add new applications or settings inside the JSON array below. 
# 
# TEMPLATE:
# {
#   "AppName": "Friendly Name for the App",
#   "RelativePath": "Folder\\_Instances\\*\\TheConfigFile.exe.config",
#   "Settings": {
#     "AppSettingKey1": "YourValueHere",
#     "AppSettingKey2": "http://{cert_name}/Service"
#   }
# }
#
# AVAILABLE PLACEHOLDERS (These will be automatically replaced during runtime):
# {hostname}         - Short computer name (e.g., SERVER01)
# {full_hostname}    - Fully qualified domain name (e.g., SERVER01.domain.local)
# {cert_name}        - The certificate name entered by the user
# {ssrs_user}        - The SSRS username entered by the user
# {ssrs_domain}      - The SSRS domain entered by the user
# {drive}            - The drive letter where the config was found (e.g., C:)
# {sub_instance}     - The name of the specific _Instances folder
# {ReportServerPath} - Auto-resolved path to the Report Server folder
# ==============================================================================
 
$jsonConfig = @"
[
  {
    "AppName": "CAD Server",
    "RelativePath": "CAD Server\\_Instances\\*\\KPI.Phoenix.CADServerSvc.exe.config",
    "Settings": {
      "KPIRMSURL": "http://{cert_name}/Police",
      "KPIFireRMSURL": "http://{cert_name}/Fire",
      "DeviceNotifySvrIP": "{hostname}",
      "DeviceNotificationSvrPort": "5555",
      "IsSignalRNotifySvc": "TRUE",
      "SignalRSvcURL": "https://{hostname}:8245",
      "RptServer_UserName": "{ssrs_user}",
      "RptServer_Domain": "{ssrs_domain}"
    }
  },
  {
    "AppName": "PnxFolderWatcher",
    "RelativePath": "PnxFolderWatcher\\_Instances\\*\\KPI.Phoenix.FolderWatcherSvc.exe.config",
    "Settings": {
      "InterfaceID": "IRPT",
      "FolderWatchPath": "{drive}\\Program Files\\ProPhoenix\\PnxFolderWatcher\\_Instances\\{sub_instance}\\Rpt\\GettxtFile",
      "ProcessedFilePath": "{drive}\\Program Files\\ProPhoenix\\PnxFolderWatcher\\_Instances\\{sub_instance}\\Rpt\\ProcessedRpt",
      "KPIAppBasePath": "{drive}\\Program Files\\ProPhoenix\\Police RMS"
    }
  },
  {
    "AppName": "E911 Server",
    "RelativePath": "E911 Server\\_Instances\\*\\KPI.Phoenix.E911ServerSvc.exe.config",
    "Settings": {
      "CADServer": "{Full_Hostname}",
      "CADServerPort": "8888",
      "CADE911ServerPort": "9998"
    }
  },
  {
    "AppName": "Device Notification Server",
    "RelativePath": "Phoenix Device Notification\\_Instances\\*\\KPI.Phoenix.DeviceNotificationSvc.exe.config",
    "Settings": {
      "DeviceAppMgrSvrIP": "{hostname}",
      "DeviceAppMgrSvrPort": "5555"
    }
  },
  {
    "AppName": "External Interface Server",
    "RelativePath": "External Interface Server\\_Instances\\*\\KPI.Phoenix.ExtInterfaceServerSvc.exe.config",
    "Settings": {
      "KPIExtWatchDir": "C:\\Program Files\\ProPhoenix\\Watch",
      "ESOResendData": "True"
    }
  },
  {
    "AppName": "NCIC Server",
    "RelativePath": "NCIC Server\\_Instances\\*\\KPI.Phoenix.NCICServerSvc.exe.config",
    "Settings": {
      "NCICStateServerIP": "{hostname}",
      "NCICStateServerPort": "5858",
      "InterfaceName": "NCIC"
    }
  },
  {
    "AppName": "NCIC State Server",
    "RelativePath": "NCIC State Server\\_Instances\\*\\KPI.Phoenix.NCICStateServerSvc.exe.config",
    "Settings": {
      "NCICServerPort": "6667",
      "NCICStateServerIP": "{hostname}",
      "NCICStateServerPort": "5858"
    }
  },
  {
    "AppName": "Phoenix CAD Live Streaming Service",
    "RelativePath": "Phoenix CAD Live Streaming Service\\_Instances\\*\\KPI.Phoenix.LiveStreaming.AzureServerSvc.exe.config",
    "Settings": {
      "CADServerIP": "{hostname}",
      "CADServerPort": "8888"
    }
  },
  {
    "AppName": "Report Server",
    "RelativePath": "Report Server\\web.config",
    "Settings": {
      "RptServer_UserName": "{ssrs_user}",
      "RptServer_Domain": "{ssrs_domain}"
    }
  },
   {
    "AppName": "Job Server",
    "RelativePath": "Job Server\\_Instances\\*\\KPI.Phoenix.JobSvc.exe.config",
    "Settings": {
      "RptServer_UserName": "{ssrs_user}",
      "RptServer_Domain": "{ssrs_domain}"
    }
  },
  {
    "AppName": "Police RMS",
    "RelativePath": "Police RMS\\web.config",
    "Settings": {
      "PnxPdfService": "https://{cert_name}/Phoenixpdfservice",
      "CSPSignatureService": "https://elink.prophoenix.com/esign/api",
      "AILicenseService": "https://crmws.prophoenix.com/PNXAIAPI"
    }
  },
  {
    "AppName": "Fire RMS",
    "RelativePath": "Fire RMS\\web.config",
    "Settings": {
      "PnxPdfService": "https://{cert_name}/Phoenixpdfservice",
      "CSPSignatureService": "https://elink.prophoenix.com/esign/api"
    }
  },
  {
    "AppName": "Internal Affairs",
    "RelativePath": "Internal Affairs\\web.config",
    "Settings": {
      "PnxPdfService": "https://{cert_name}/Phoenixpdfservice",
      "CSPSignatureService": "https://elink.prophoenix.com/esign/api"
    }
  },
  {
    "AppName": "WebService",
    "RelativePath": "WebService\\web.config",
    "Settings": {
      "xslPath": "{ReportServerPath}",
      "DeviceNotifySvrIP": "{hostname}",
      "DeviceNotificationSvrPort": "5555",
      "IsWCFChannelEnabled": "TRUE"
    }
  },
  {
    "AppName": "Phoenix Report Writer API",
    "RelativePath": "Phoenix Report Writer API\\appsettings.json",
    "Settings": {
      "JwtExpireDays": 30,
      "TemplatePath": "{drive}\\Program Files\\ProPhoenix\\Report Server\\Police\\Reports",
      "BasePath": "{drive}\\Program Files\\ProPhoenix\\Police RMS",
      "NIBRS_APIServ": "{hostname}/NibrsService/api/PnxNibrs/NibrsValidation"
    }
  }
]
"@
 
# ==============================================================================
# SCRIPT EXECUTION STARTS HERE
# ==============================================================================
 
# Verify Administrator Privileges
$isAdmin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
if (-not $isAdmin) {
    Write-Host "[FAILED] ERROR: This script must be run as Administrator to modify files in Program Files." -ForegroundColor Red
    Write-Host "Please restart your Installation Dashboard tool as Administrator." -ForegroundColor Yellow
    Pause
    exit
}
 
# Parse the embedded JSON
$appConfigs = $jsonConfig | ConvertFrom-Json
 
Write-Host "`n========================================" -ForegroundColor Cyan
Write-Host "  Welcome to Auto Configuration Scripts" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "UpComing Prompts = SSRS Username, SSRS Domain Name, Certificate name" -ForegroundColor Cyan
 
# Prompt for SSRS Report Server credentials
$ssrsUser = Read-Host "`nEnter SSRS Report Server Username"
$ssrsDomain = Read-Host "Enter SSRS Domain"
 
# Prompt for certificate name (used in selective keys)
$certName = Read-Host "Enter Certificate Name"
Write-Host "Certificate to be used: $certName"
 
# Get dynamic environment info
$hostname = [System.Net.Dns]::GetHostName()
$fullHostname = [System.Net.Dns]::GetHostEntry($hostname).HostName
 
# Get local IPv4 address (excluding loopbacks)
$ipAddress = [System.Net.Dns]::GetHostAddresses($hostname) | Where-Object {
    $_.AddressFamily -eq 'InterNetwork' -and $_.IPAddressToString -notlike '127.*'
} | Select-Object -First 1
 
# Display system info
Write-Host "`n==== Environment Info ====" -ForegroundColor Cyan
Write-Host "Hostname       : $hostname"
Write-Host "Full Hostname  : $fullHostname"
Write-Host "IP Address     : $($ipAddress.IPAddressToString)"
Write-Host "===========================" -ForegroundColor Cyan
 
# Detect ProPhoenix base paths across all drives
$ppBasePaths = Get-PSDrive -PSProvider 'FileSystem' | ForEach-Object {
    $rootPath = Join-Path $_.Root "Program Files\ProPhoenix"
    if (Test-Path $rootPath) { $rootPath }
}
 
if (-not $ppBasePaths) {
    Write-Error "ProPhoenix base path not found on any drive!"
    exit 1
}
 
Write-Host "Detected base ProPhoenix paths on drives:" -ForegroundColor Cyan
$ppBasePaths | ForEach-Object { Write-Host "  $_" }
 
# Global replacements
$replacements = @{
    'hostname'      = $hostname
    'fullhostname'  = $fullHostname
    'full_hostname' = $fullHostname
    'cert_name'     = $certName
    'ssrs_user'     = $ssrsUser       
    'ssrs_domain'   = $ssrsDomain     
}
 
# Keys where cert_name should be replaced
$keysToUseCertName = @("KPIRMSURL", "KPIFireRMSURL", "PnxPdfService")
 
# Robust XML Update Function
function UpdateOrAddKey([xml]$xmlDoc, [System.Xml.XmlElement]$settingsNode, $key, $value, $subInstance) {
    $replacements['sub_instance'] = $subInstance
    $finalValue = $value
 
    # Apply Placeholders
    foreach ($placeholder in $replacements.Keys) {
        if (($key -in $keysToUseCertName -and $placeholder -eq 'cert_name') -or
            ($key -notin $keysToUseCertName -and $placeholder -ne 'cert_name')) {
            $finalValue = $finalValue -replace "(?i)\{$placeholder\}", $replacements[$placeholder]
        }
    }
 
    # Find node using XPath to safely bypass PowerShell wrapper case-sensitivity
    $xpath = "*[local-name()='add' and (@key='$key' or @Key='$key')]"
    $node = $settingsNode.SelectSingleNode($xpath)
 
    if ($node) {
        # Update existing (safely checking original attribute case)
        if ($node.HasAttribute("Value")) {
            $node.SetAttribute("Value", $finalValue)
        } else {
            $node.SetAttribute("value", $finalValue)
        }
    } else {
        # Create new element using the parent's namespace
        $newElem = $xmlDoc.CreateElement("add", $settingsNode.NamespaceURI)
        $newElem.SetAttribute("key", $key)
        $newElem.SetAttribute("value", $finalValue)
        $settingsNode.AppendChild($newElem) | Out-Null
    }
}
 
# Loop through apps
foreach ($app in $appConfigs) {
    Write-Host "`nProcessing: $($app.AppName)" -ForegroundColor Cyan
 
    $matchedFiles = @()
 
    foreach ($basePath in $ppBasePaths) {
        $searchPattern = Join-Path $basePath ($app.RelativePath -replace '\\', [IO.Path]::DirectorySeparatorChar)
        $found = Get-ChildItem -Path $searchPattern -File -ErrorAction SilentlyContinue
        if ($found) {
            $matchedFiles += $found
        }
    }
 
    if (-not $matchedFiles) {
        Write-Host ("[SKIP]".PadRight(8) + "No files found for pattern: $($app.RelativePath)") -ForegroundColor DarkYellow
        continue
    }
 
    foreach ($configFile in $matchedFiles) {
        $subInstance = $configFile.Directory.Name
        $replacements['sub_instance'] = $subInstance
        $replacements['drive'] = ($configFile.Directory.Root.FullName).TrimEnd('\')
        $replacements['reportserverpath'] = Join-Path $replacements['drive'] "Program Files\ProPhoenix\Report Server"
 
        Write-Host ("[FILE]".PadRight(8) + "Updating config: $($configFile.FullName)") -ForegroundColor Yellow
 
        $extension = $configFile.Extension.ToLower()
 
        # Folder Creation Logic
        foreach ($kv in $app.Settings.PSObject.Properties) {
            if ($kv.Name -match 'Path$') {
                $resolvedPath = $kv.Value
                foreach ($p in @('drive', 'sub_instance')) {
                    $resolvedPath = $resolvedPath -replace "(?i)\{$p\}", $replacements[$p]
                }
                if (-not (Test-Path $resolvedPath)) {
                    try {
                        New-Item -Path $resolvedPath -ItemType Directory -Force | Out-Null
                        Write-Host ("   -> Created missing path: ".PadRight(28) + "$resolvedPath") -ForegroundColor DarkGray
                    } catch {
                        Write-Host ("[FAIL]".PadRight(8) + "FAILED to create path: $resolvedPath") -ForegroundColor Red
                    }
                }
            }
        }
 
        # Safely attempt to read, modify, and save the files
        try {
            # ==========================================
            # HANDLE JSON FILES (e.g., appsettings.json)
            # ==========================================
            if ($extension -eq '.json') {
                $fileContent = [System.IO.File]::ReadAllText($configFile.FullName)
                $jsonObj = $fileContent | ConvertFrom-Json
 
                # FIX: Handle nested .NET Core AppSettings block if it exists
                $targetObj = $jsonObj
                if ($null -ne $jsonObj.PSObject.Properties['AppSettings']) {
                    $targetObj = $jsonObj.AppSettings
                }
 
                foreach ($kv in $app.Settings.PSObject.Properties) {
                    $key = $kv.Name
                    $val = $kv.Value
 
                    if ($val -is [string]) {
                        foreach ($p in $replacements.Keys) {
                            $val = $val -replace "(?i)\{$p\}", $replacements[$p]
                        }
                    }
 
                    if ($null -ne $targetObj.PSObject.Properties[$key]) {
                        $targetObj.$key = $val
                    } else {
                        $targetObj | Add-Member -MemberType NoteProperty -Name $key -Value $val
                    }
                    Write-Host ("   -> Updated JSON key: ".PadRight(28) + "$key".PadRight(35) + "[OK]") -ForegroundColor DarkGray
                }
 
                # Save the JSON back bypassing Out-File BOM issues
                $jsonString = $jsonObj | ConvertTo-Json -Depth 10
                [System.IO.File]::WriteAllText($configFile.FullName, $jsonString)
                Write-Host ("[OK]".PadRight(8) + "Updated successfully: $($configFile.Name)") -ForegroundColor Green
            }
            # ==========================================
            # HANDLE XML FILES (e.g., .config)
            # ==========================================
            elseif ($extension -eq '.config') {
                $fileContent = [System.IO.File]::ReadAllText($configFile.FullName)
                [xml]$xml = $fileContent
 
                # Robustly find configuration node ignoring namespaces/casing
                $configNode = $xml.SelectSingleNode("//*[local-name()='configuration']")
                if (-not $configNode) {
                    $configNode = $xml.SelectSingleNode("//*[local-name()='Configuration']")
                }
 
                if ($configNode) {
                    $appSettings = $configNode.SelectSingleNode("*[local-name()='appSettings']")
                    if (-not $appSettings) {
                        $appSettings = $xml.CreateElement("appSettings", $configNode.NamespaceURI)
                        $configNode.AppendChild($appSettings) | Out-Null
                    }
 
                    foreach ($kv in $app.Settings.PSObject.Properties) {
                        UpdateOrAddKey -xmlDoc $xml -settingsNode $appSettings -key $kv.Name -value $kv.Value -subInstance $subInstance
                        Write-Host ("   -> Updated XML key: ".PadRight(28) + "$($kv.Name)".PadRight(35) + "[OK]") -ForegroundColor DarkGray
                    }
 
                    $xml.Save($configFile.FullName)
                    Write-Host ("[OK]".PadRight(8) + "Updated successfully: $($configFile.Name)") -ForegroundColor Green
                } else {
                    Write-Host ("[FAIL]".PadRight(8) + "Root <configuration> node not found.") -ForegroundColor Red
                }
            }
        } catch {
            Write-Host ("[FAIL]".PadRight(8) + "FAILED on file: $($configFile.FullName)") -ForegroundColor Red
            Write-Host "        Error Details: $($_.Exception.Message)" -ForegroundColor Red
        }
    }
}
 
Write-Host "`nScript has finished running!" -ForegroundColor Cyan

Read-Host -Prompt "Press Enter to close the terminal"
[Environment]::Exit(0)