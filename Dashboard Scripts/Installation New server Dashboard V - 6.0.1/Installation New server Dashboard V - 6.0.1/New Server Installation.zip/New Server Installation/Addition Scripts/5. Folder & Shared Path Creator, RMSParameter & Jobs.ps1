﻿#Requires -RunAsAdministrator

Write-Host "=======================================================" -ForegroundColor Cyan
Write-Host "  ProPhoenix Enterprise Setup, DB & Jobs Configurator" -ForegroundColor Cyan
Write-Host "=======================================================" -ForegroundColor Cyan

$hostName = $env:COMPUTERNAME
$folderSummary = @()
$shareSummary = @()

# ==========================================
# 1. Fetch the Base Path Automatically
# ==========================================
$baseFolder = "Program Files\ProPhoenix"
$foundPaths = @()

# Scan all drives for the ProPhoenix folder
foreach ($drive in (Get-PSDrive -PSProvider FileSystem)) {
    $testPath = Join-Path -Path $drive.Root -ChildPath $baseFolder
    if (Test-Path $testPath) {
        $foundPaths += $testPath
    }
}

# Determine the Base Path based on scan results
if ($foundPaths.Count -eq 0) {
    $basePath = "$($env:SystemDrive)\$baseFolder"
    Write-Host "ProPhoenix base path not found. Defaulting to: $basePath" -ForegroundColor Yellow
} elseif ($foundPaths.Count -eq 1) {
    $basePath = $foundPaths[0]
    Write-Host "Found Base Path: $basePath" -ForegroundColor Green
} else {
    Write-Host "`nMultiple ProPhoenix installations found. Please select the correct Base Path:" -ForegroundColor Yellow
    for ($i = 0; $i -lt $foundPaths.Count; $i++) { 
        Write-Host "$($i + 1). $($foundPaths[$i])" 
    }
    
    $validChoice = $false
    while (-not $validChoice) {
        $pathChoice = Read-Host "Enter your choice (1-$($foundPaths.Count))"
        if ([int]::TryParse($pathChoice, [ref]$null) -and [int]$pathChoice -ge 1 -and [int]$pathChoice -le $foundPaths.Count) {
            $basePath = $foundPaths[[int]$pathChoice - 1]
            $validChoice = $true
        } else {
            Write-Host "Invalid selection. Please enter a number between 1 and $($foundPaths.Count)." -ForegroundColor Red
        }
    }
    Write-Host "Selected Base Path: $basePath" -ForegroundColor Green
}

# ==========================================
# 2. Configure ASP State Service
# ==========================================
Write-Host "`nConfiguring ASP.NET State Service..." -ForegroundColor Cyan
try {
    Set-Service -Name "aspnet_state" -StartupType Automatic -ErrorAction Stop
    Start-Service -Name "aspnet_state" -ErrorAction Stop
    Write-Host "ASP.NET State Service set to Automatic and Started successfully." -ForegroundColor Green
} catch {
    Write-Host "Warning: Failed to configure aspnet_state service. It may not be installed. $_" -ForegroundColor Yellow
}

# ==========================================
# 3. Apply NTFS Permissions to ProPhoenix Folder
# ==========================================
Write-Host "`nApplying NTFS Permissions to $basePath..." -ForegroundColor Cyan
if (!(Test-Path $basePath)) { New-Item -ItemType Directory -Path $basePath -Force | Out-Null }

try {
    $acl = Get-Acl -Path $basePath
    
    # Get Current User
    $currentUser = [System.Security.Principal.WindowsIdentity]::GetCurrent().Name
    
    # Get local Administrators group safely using Universal SID
    $adminSid = New-Object System.Security.Principal.SecurityIdentifier("S-1-5-32-544")
    $adminGroup = $adminSid.Translate([System.Security.Principal.NTAccount]).Value
    
    # Get local Users group safely using Universal SID
    $usersSid = New-Object System.Security.Principal.SecurityIdentifier("S-1-5-32-545")
    $usersGroup = $usersSid.Translate([System.Security.Principal.NTAccount]).Value
    
    # Combine all target identities and remove any potential duplicates
    $targetIdentities = @($currentUser, $adminGroup, $usersGroup, "NT AUTHORITY\NETWORK SERVICE", "NT AUTHORITY\IUSR") | Select-Object -Unique

    foreach ($identity in $targetIdentities) {
        $accessRule = New-Object System.Security.AccessControl.FileSystemAccessRule(
            $identity, 
            "FullControl", 
            "ContainerInherit,ObjectInherit", 
            "None", 
            "Allow"
        )
        $acl.AddAccessRule($accessRule)
    }
    Set-Acl -Path $basePath -AclObject $acl
    Write-Host "Full Control granted to Current User, $adminGroup, $usersGroup, Network Service, and IUSR." -ForegroundColor Green
} catch {
    Write-Host "Error applying folder permissions: $_" -ForegroundColor Red
}

# ==========================================
# 4. Fetch Instance Folders & Process Directories
# ==========================================
$cadInstances = @()
$pnxInstances = @()

$cadInstancePath = Join-Path $basePath "CAD Server\_Instances"
if (Test-Path $cadInstancePath) { $cadInstances = (Get-ChildItem -Path $cadInstancePath -Directory).Name }

$pnxInstancePath = Join-Path $basePath "PnxFolderWatcher\_Instance"
if (Test-Path $pnxInstancePath) { $pnxInstances = (Get-ChildItem -Path $pnxInstancePath -Directory).Name }

# Core folders that SHOULD be forced created if missing
$foldersToCreate = @(
    "Custom", "Attachment", "Attachment\Job", "Watch", "WatchTr", "ScreenDocs", "Attachment\BulkUpload"
)

# Conditionally added folders based on parent existence
if (Test-Path (Join-Path $basePath "Police RMS\Records")) { $foldersToCreate += "Police RMS\Records\Hotsheet" }
if (Test-Path (Join-Path $basePath "FTP")) { 
    $foldersToCreate += "FTP\CAD Data\KPIDATA"
    $foldersToCreate += "FTP\WDA Data\KPIDATA"
}

# Only create Bolo and Rpt folders IF the instance parent directory actually exists
foreach ($cadInst in $cadInstances) { 
    $foldersToCreate += "CAD Server\_Instances\$cadInst\Bolo" 
}

foreach ($pnxInst in $pnxInstances) {
    $foldersToCreate += "PnxFolderWatcher\_Instance\$pnxInst\Rpt"
    $foldersToCreate += "PnxFolderWatcher\_Instance\$pnxInst\Rpt\GettxtFile"
    $foldersToCreate += "PnxFolderWatcher\_Instance\$pnxInst\Rpt\ProcessedRpt"
    $foldersToCreate += "PnxFolderWatcher\_Instance\$pnxInst\Rpt\ErrorRpt"
}

# These folders should ONLY be verified/shared, NEVER forcibly created
$appFoldersToVerify = @(
    "WDA App webservice", "Phoenix Report Writer API", "Fire WebService", 
    "Fire Response CAD Webservice", "Police RMS\Log"
)

Write-Host "`nScanning and Validating Directories..." -ForegroundColor Cyan

# 1. Create essential folders if missing
foreach ($folder in $foldersToCreate) {
    $fullPath = Join-Path $basePath $folder
    if (-not (Test-Path $fullPath)) {
        New-Item -ItemType Directory -Path $fullPath -Force | Out-Null
        $folderSummary += [PSCustomObject]@{ Status = "Created"; Path = $fullPath }
    } else {
        $folderSummary += [PSCustomObject]@{ Status = "Existing (Used)"; Path = $fullPath }
    }
}

# 2. Verify application folders (Do NOT create)
foreach ($appFolder in $appFoldersToVerify) {
    $fullPath = Join-Path $basePath $appFolder
    if (Test-Path $fullPath) {
        $folderSummary += [PSCustomObject]@{ Status = "Existing (Verified)"; Path = $fullPath }
    } else {
        $folderSummary += [PSCustomObject]@{ Status = "Missing (Skipped)"; Path = $fullPath }
    }
}


# ==========================================
# 5. Create/Verify Shared Folders
# ==========================================
Write-Host "`nScanning and Validating Network Shares..." -ForegroundColor Cyan

$sharesToManage = @{
    "Custom" = "Custom"
    "Job" = "Attachment\Job"
    "Hotsheet" = "Police RMS\Records\Hotsheet"
    "ScreenDocs" = "ScreenDocs"
    "Attachment" = "Attachment"
    "BulkUpload" = "Attachment\BulkUpload"
    "ftp" = "FTP"
    "Watch" = "Watch"
    "WDA App webservice" = "WDA App webservice"
    "Phoenix Report Writer API" = "Phoenix Report Writer API"
    "Fire WebService" = "Fire WebService"
    "Fire Response CAD Webservice" = "Fire Response CAD Webservice"
}

# Dynamically assign Bolo share names based on Instance Name
foreach ($cadInst in $cadInstances) {
    $boloRelPath = "CAD Server\_Instances\$cadInst\Bolo"
    
    if ($cadInst -match "Live") {
        $sharesToManage["Bolo"] = $boloRelPath
    } 
    elseif ($cadInst -match "Training") {
        $sharesToManage["Bolo2"] = $boloRelPath
    } 
    else {
        # Fallback for other instances (e.g., Test -> Bolo_Test)
        $sharesToManage["Bolo_$cadInst"] = $boloRelPath
    }
}

# Execute Share Creation (Only happens if the local Test-Path is True)
foreach ($shareName in $sharesToManage.Keys) {
    $targetFolderPath = Join-Path $basePath $sharesToManage[$shareName]
    
    if (Test-Path $targetFolderPath) {
        $existingShare = Get-SmbShare -Name $shareName -ErrorAction SilentlyContinue
        $uncPath = "\\$hostName\$shareName"

        if (-not $existingShare) {
            New-SmbShare -Name $shareName -Path $targetFolderPath -FullAccess "Everyone" | Out-Null
            $shareSummary += [PSCustomObject]@{ Status = "Created"; ShareName = $shareName; UNC = $uncPath }
        } else {
            $shareSummary += [PSCustomObject]@{ Status = "Existing (Used)"; ShareName = $shareName; UNC = $uncPath }
        }
    }
}

# ==========================================
# 6. Summary Output
# ==========================================
Write-Host "`n=======================================================" -ForegroundColor Cyan
Write-Host "  Setup Summary Report" -ForegroundColor Cyan
Write-Host "=======================================================" -ForegroundColor Cyan

Write-Host "`n--- Folder Status ---" -ForegroundColor Yellow
$folderSummary | Format-Table -AutoSize

Write-Host "--- Share Status ---" -ForegroundColor Yellow
$shareSummary | Format-Table -AutoSize

Read-Host -Prompt "Press Enter to close the terminal"
[Environment]::Exit(0)