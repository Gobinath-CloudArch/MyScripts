# 1. Prompt for Server and Version details
$serverName = Read-Host "Enter the SQL Server Name (e.g., CHPNX868)"

Write-Host "" # Adds a blank line for readability

# Stack the options one by one
Write-Host "Select SSRS Version:"
Write-Host "  1 - Below 2019 [v15]"
Write-Host "  2 - 2019-2022 [v16]"
$versionChoice = Read-Host "Enter your choice (1 or 2)"

if ($versionChoice -eq "1") { 
    $version = "v15" 
} else { 
    $version = "v16" 
}

# 2. Prompt for Credentials securely
# This will pop up a standard Windows login box
$cred = Get-Credential -UserName "sa" -Message "Enter the SQL Server 'sa' credentials"

$saUser = $cred.GetNetworkCredential().Username
$saPassword = $cred.GetNetworkCredential().Password

function Get-ConfigSet() {
    return Get-WmiObject -namespace "root\Microsoft\SqlServer\ReportServer\RS_SSRS\$version\Admin" `
        -class MSReportServer_ConfigurationSetting -ComputerName $env:COMPUTERNAME
}

# Allow importing of sqlps module
# Try to set the policy for this script's process only, and hide the error if a higher policy overrides it
Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope Process -Force -ErrorAction SilentlyContinue

# Retrieve the current configuration
$configset = Get-ConfigSet

# ---------------------------------------------------------------------------------
# NEW: Configure Service Account to Network Service
# ---------------------------------------------------------------------------------
Write-Host "Configuring Report Server Service Account to use built-in Network Service..."
$svcResult = $configset.SetWindowsServiceIdentity($true, "NetworkService", "")

if ($svcResult.HRESULT -eq 0) {
    Write-Host "Successfully updated the Service Account to Network Service."
    # Restart the service to apply the identity change and refresh WMI
    Restart-Service $configset.ServiceName -Force
    Start-Sleep -Seconds 3
    $configset = Get-ConfigSet
} else {
    Write-Host "Warning: Failed to set Service Account. HRESULT: $($svcResult.HRESULT)"
}

If (! $configset.IsInitialized) {
    # Get the ReportServer and ReportServerTempDB creation script
    [string]$dbscript = $configset.GenerateDatabaseCreationScript("ReportServer", 1033, $false).Script

    Write-Host "Database Creation Script Executing..."

    $commands = $dbscript -split '\bGO\b'

    # Import the SQL Server PowerShell module
    Import-Module sqlps -DisableNameChecking | Out-Null

    # Create the connection
    $connectionString = "Server=$serverName;Database=master;User ID=$saUser;Password=$saPassword;"
    $conn = New-Object System.Data.SqlClient.SqlConnection($connectionString)

    try {
        $conn.Open()
        Write-Host "Successfully connected to SQL Server as '$saUser'."

        $cmd = $conn.CreateCommand()

        # Execute each command individually
        foreach ($command in $commands) {
            $command = $command.Trim()
            if (-not [string]::IsNullOrEmpty($command)) {
                try {
                    $cmd.CommandText = $command
                    $cmd.ExecuteNonQuery() | Out-Null
                } catch {
                    Write-Host "Error executing script block: $_.Exception.Message"
                }
            }
        }

        Write-Host "Database 'ReportServer' created successfully."

        # Now, retrieve the database object
        $smoConnection = New-Object Microsoft.SqlServer.Management.Common.ServerConnection($conn)
        $smo = New-Object Microsoft.SqlServer.Management.Smo.Server -ArgumentList $smoConnection
        $db = $smo.Databases["ReportServer"]

        # Set permissions for the databases (This will now correctly apply to Network Service)
        if ($db -ne $null) {
            $dbscript = $configset.GenerateDatabaseRightsScript($configset.WindowsServiceIdentityConfigured, "ReportServer", $false, $true).Script
            Write-Host "Executing permission script on the database."
            $db.ExecuteNonQuery($dbscript)
        }

        # ---------------------------------------------------------------------------------
        # Set the database connection info using SQL Authentication ('sa' credentials)
        # ---------------------------------------------------------------------------------
        Write-Host "Configuring Report Server Database Credentials to use SQL account '$saUser'..."
        
        $dbConnResult = $configset.SetDatabaseConnection($serverName, "ReportServer", 1, $saUser, $saPassword)
        
        if ($dbConnResult.HRESULT -eq 0) {
            Write-Host "Successfully updated the Database Credentials in Configuration Manager."
        } else {
            Write-Host "Warning: Failed to update Database Credentials. HRESULT: $($dbConnResult.HRESULT)"
        }

        # Configure Web Service URL
        $configset.SetVirtualDirectory("ReportServerWebService", "ReportServer", 1033)
        $configset.ReserveURL("ReportServerWebService", "http://+:80", 1033)

        # Configure Web Portal URL
        $configset.SetVirtualDirectory("ReportServerWebApp", "Reports", 1033)
        $configset.ReserveURL("ReportServerWebApp", "http://+:80", 1033)

        # Initialize Report Server
        $configset.InitializeReportServer($configset.InstallationID)

        # Re-start services
        $configset.SetServiceState($false, $false, $false)
        Restart-Service $configset.ServiceName
        $configset.SetServiceState($true, $true, $true)

        # Update the current configuration
        $configset = Get-ConfigSet
        $inst = Get-WmiObject -namespace "root\Microsoft\SqlServer\ReportServer\RS_SSRS\$version" `
            -class MSReportServer_Instance -ComputerName $env:COMPUTERNAME
        
        Write-Host "Report Server URLs configured:"
        $inst.GetReportServerUrls()

    } catch {
        Write-Host "Error Message: $_.Exception.Message"
    } finally {
        $conn.Close() 
    }
}

# Define the path to the rsreportserver.config file
$configFilePath = "C:\Program Files\Microsoft SQL Server Reporting Services\SSRS\ReportServer\rsreportserver.config"

# Load the XML configuration file
[xml]$configXml = Get-Content -Path $configFilePath

# Define the XPath to the AuthenticationTypes node
$authTypesNode = $configXml.SelectSingleNode("//AuthenticationTypes")

if ($authTypesNode -ne $null) {
    $existingNegotiateNode = $authTypesNode.SelectSingleNode("RSWindowsNegotiate")
    
    if ($existingNegotiateNode -eq $null) {
        $newAuthNode = $configXml.CreateElement("RSWindowsNegotiate")
        $authTypesNode.AppendChild($newAuthNode) | Out-Null
        $configXml.Save($configFilePath)
        Write-Host "Added <RSWindowsNegotiate/> to the AuthenticationTypes section."
    } else {
        Write-Host "<RSWindowsNegotiate/> already exists in the AuthenticationTypes section."
    }
}

$ssrsServiceName = "SQL Server Reporting Services"
Restart-Service -Name $ssrsServiceName -Force
Write-Host "SSRS service has been restarted."


Write-Host "`nScript has finished running!" -ForegroundColor Cyan


Read-Host -Prompt "Press Enter to close the terminal"
[Environment]::Exit(0)