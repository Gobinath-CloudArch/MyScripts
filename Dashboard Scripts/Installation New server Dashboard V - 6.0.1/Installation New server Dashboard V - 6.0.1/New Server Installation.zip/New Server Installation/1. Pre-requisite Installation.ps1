﻿# ==============================================================================
# ProPhoenix Pre-requisite, IIS Deployment & Environment Audit
# Version: 5.1 (Hardened Environmental Checks)
# ==============================================================================
Clear-Host 

$ErrorActionPreference = "Stop"

Write-Host "`n========================================================" -ForegroundColor Cyan
Write-Host "  PHASE 0: PRE-FLIGHT ENVIRONMENTAL VALIDATIONS" -ForegroundColor Cyan
Write-Host "========================================================" -ForegroundColor Cyan

# --- 1. PowerShell Version Check ---
if ($PSVersionTable.PSVersion.Major -lt 5) {
    Write-Host "`n[FAIL] Unsupported Environment." -ForegroundColor Red
    Write-Host "Reason: PowerShell 5.0 or higher is required. You are running version $($PSVersionTable.PSVersion.Major)." -ForegroundColor Yellow
    Write-Host "Fix: Please install the Windows Management Framework (WMF) 5.1 update for this OS." -ForegroundColor Gray
    Read-Host -Prompt "Press Enter to close the terminal"
    exit
}
Write-Host "  [OK] PowerShell Version: $($PSVersionTable.PSVersion.Major)" -ForegroundColor Green

# --- 2. Administrator Privilege Check ---
if (-not ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")) {
    Write-Host "`n[FAIL] Insufficient Privileges." -ForegroundColor Red
    Write-Host "Reason: The script is attempting to install software and modify system registries, which requires an elevated prompt." -ForegroundColor Yellow
    Write-Host "Fix: Please close this window, right-click the script (or PowerShell), and select 'Run as Administrator'." -ForegroundColor Gray
    Read-Host -Prompt "Press Enter to close the terminal"
    exit
}
Write-Host "  [OK] Administrator Privileges Confirmed" -ForegroundColor Green

# --- 3. OS Architecture & WMI Check ---
try {
    $osInfo = Get-CimInstance -ClassName Win32_OperatingSystem -ErrorAction Stop
    if (-not [Environment]::Is64BitOperatingSystem) {
        Write-Host "`n[WARNING] 32-bit Operating System Detected." -ForegroundColor Yellow
        Write-Host "Reason: You are running a 32-bit OS. Some modern components (like 64-bit Crystal Reports) will be skipped or may fail." -ForegroundColor Gray
    } else {
        Write-Host "  [OK] 64-bit Architecture Confirmed ($($osInfo.Caption))" -ForegroundColor Green
    }
} catch {
    Write-Host "`n[FAIL] WMI Subsystem Error." -ForegroundColor Red
    Write-Host "Reason: Unable to query the OS configuration via WMI. The Windows Management Instrumentation service may be corrupted or stopped." -ForegroundColor Yellow
    Write-Host "Details: $($_.Exception.Message)" -ForegroundColor Gray
    Read-Host -Prompt "Press Enter to close the terminal"
    exit
}

# --- 4. Network & Azure Blob Isolation Check ---
Write-Host "  Testing secure connection to Azure Blob Storage..." -ForegroundColor Gray
try {
    $blobTest = Test-NetConnection -ComputerName "produpdates.blob.core.windows.net" -Port 443 -InformationLevel Quiet -WarningAction SilentlyContinue
    if (-not $blobTest) {
        Write-Host "`n[FAIL] Network Isolation / Firewall Block." -ForegroundColor Red
        Write-Host "Reason: Cannot reach 'produpdates.blob.core.windows.net' over HTTPS (Port 443)." -ForegroundColor Yellow
        Write-Host "Fix: Kindly verify DNS resolution and enable outbound internet/Blob access for this Server's public IP." -ForegroundColor Gray
        Read-Host -Prompt "Press Enter to close the terminal"
        exit
    }
    Write-Host "  [OK] Blob Connection Successful" -ForegroundColor Green
} catch {
    Write-Host "`n[FAIL] Network Command Failed." -ForegroundColor Red
    Write-Host "Reason: The Test-NetConnection command crashed. Ensure your network adapter is functioning properly." -ForegroundColor Yellow
    Write-Host "Details: $($_.Exception.Message)" -ForegroundColor Gray
    Read-Host -Prompt "Press Enter to close the terminal"
    exit
}

# --- 5. Robust Drive Letter Prompting ---
Write-Host "`n========================================================" -ForegroundColor Cyan
Write-Host "  SYSTEM CONFIGURATION INITIALIZATION" -ForegroundColor Cyan
Write-Host "========================================================" -ForegroundColor Cyan

function Get-ValidDrive {
    param ([string]$PromptMessage)
    while ($true) {
        $drive = (Read-Host $PromptMessage).ToUpper().Trim()
        if ($drive -match "^[A-Z]$") {
            if (Test-Path "$($drive):\" -ErrorAction SilentlyContinue) {
                return $drive
            } else {
                Write-Host "  [WARNING] Drive $($drive):\ does not exist or is inaccessible. Try again." -ForegroundColor Yellow
            }
        } else {
            Write-Host "  [WARNING] Invalid format. Please enter a single letter (e.g., C, D, E)." -ForegroundColor Yellow
        }
    }
}

$installDrive = Get-ValidDrive "Enter Primary Installation Drive Letter (e.g., C)"
$phoenixAppManagerInstallDrive = Get-ValidDrive "Enter Phoenix App Manager Install Drive (e.g., C)"
$backupDrive = Get-ValidDrive "Enter Backup/Logs Drive Letter for machine.config (e.g., D)"

Write-Host "Proceeding with installation..." -ForegroundColor Green

# --- 6. Global Status Tracker ---
$global:ExecutionSummary = [System.Collections.Generic.List[PSCustomObject]]::new()
$global:PendingRestart = $false

Function Record-TaskStatus {
    param([string]$TaskName, [string]$Status, [string]$Details = "")
    $global:ExecutionSummary.Add([PSCustomObject]@{
        Task    = $TaskName
        Status  = $Status
        Details = $Details
    })
}

# --- 7. Directory & Logging Setup ---

$tempInstallPath = "${installDrive}:\PnxTemp"
if (!(Test-Path -Path $tempInstallPath)) { New-Item -Path $tempInstallPath -ItemType Directory -Force | Out-Null }

$phoenixAppManagerTempPath = "${phoenixAppManagerInstallDrive}:\PnxTemp"
if (!(Test-Path -Path $phoenixAppManagerTempPath)) { New-Item -Path $phoenixAppManagerTempPath -ItemType Directory -Force | Out-Null }

$script:LogFilePath = "$tempInstallPath\SystemSetup_$(Get-Date -Format 'yyyyMMdd_HHmmss').log"

Function Write-Log {
    param([string]$Message, [string]$Level = "INFO", [switch]$NoConsole)
    $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    $logEntry = "[$timestamp] [$Level] $Message"
    
    if (-not [string]::IsNullOrEmpty($script:LogFilePath)) {
        Add-Content -Path $script:LogFilePath -Value $logEntry -ErrorAction SilentlyContinue
    }
    
    if (-not $NoConsole) {
        switch ($Level) {
            "INFO" { Write-Host $logEntry -ForegroundColor White }
            "WARNING" { Write-Host $logEntry -ForegroundColor Yellow }
            "ERROR" { Write-Host $logEntry -ForegroundColor Red }
            "SUCCESS" { Write-Host $logEntry -ForegroundColor Green }
            default { Write-Host $logEntry -ForegroundColor Gray }
        }
    }
}

Write-Log "Initialization complete. Log path: $script:LogFilePath"

# --- 8. Helper Functions ---

Function Get-FipsRegistryStatus {
    try {
        $fipsEnabled = (Get-ItemProperty -Path "HKLM:\System\CurrentControlSet\Control\Lsa\FipsAlgorithmPolicy" -Name "Enabled" -ErrorAction Stop).Enabled
        return ($fipsEnabled -eq 1)
    } catch { return $false }
}

# Standard Installer (MSI/EXE)
Function Install-Package {
    param(
        [Parameter(Mandatory=$true)][string]$Url,
        [Parameter(Mandatory=$true)][string]$DestinationPath,
        [Parameter(Mandatory=$true)][string]$SoftwareName,
        [string[]]$InstallArgs = @("/passive", "/norestart", "/qn"),
        [string]$UninstallDisplayName
    )

    Write-Log "`nProcessing: $SoftwareName"
    
    if ($UninstallDisplayName) {
        $uninstallPaths = @("HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*", "HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*")
        if (Get-ItemProperty -Path $uninstallPaths -ErrorAction SilentlyContinue | Where-Object { $_.DisplayName -like "*$UninstallDisplayName*" }) {
            Write-Log "$SoftwareName is already installed. Skipping." -Level SUCCESS
            Record-TaskStatus -TaskName "Install: $SoftwareName" -Status "Skipped" -Details "Already Installed"
            return
        }
    }

    try {
        Write-Log "Downloading $SoftwareName..."
        Invoke-WebRequest -Uri $Url -OutFile $DestinationPath -UseBasicParsing -ErrorAction Stop

        Write-Log "Installing $SoftwareName..."
        $process = if ($DestinationPath.ToLower().EndsWith(".msi")) {
            Start-Process "msiexec.exe" -ArgumentList ("/i `"$DestinationPath`" " + ($InstallArgs -join " ")) -Wait -PassThru -ErrorAction Stop
        } else { 
            Start-Process $DestinationPath -ArgumentList $InstallArgs -Wait -PassThru -ErrorAction Stop
        }

        if ($process.ExitCode -in @(0, 3010)) {
            Write-Log "$SoftwareName installed successfully." -Level SUCCESS
            Record-TaskStatus -TaskName "Install: $SoftwareName" -Status "Success" -Details $(if ($process.ExitCode -eq 3010) {"Reboot Required"} else {"Success"})
            if ($process.ExitCode -eq 3010) { $global:PendingRestart = $true }
            Write-Log "Retained installer package at $DestinationPath" -Level INFO
        } else {
            Write-Log "Installation failed. Code: $($process.ExitCode)." -Level ERROR
            Record-TaskStatus -TaskName "Install: $SoftwareName" -Status "Failed" -Details "Exit Code: $($process.ExitCode)"
        }
    } catch {
        Write-Log "Error: $($_.Exception.Message)" -Level ERROR
        Record-TaskStatus -TaskName "Install: $SoftwareName" -Status "Failed" -Details "Exception Occurred"
    }
}

# Handles ZIP files
Function Install-ZippedPackage {
    param(
        [Parameter(Mandatory=$true)][string]$Url,
        [Parameter(Mandatory=$true)][string]$ZipPath,
        [Parameter(Mandatory=$true)][string]$ExtractFolder,
        [Parameter(Mandatory=$true)][string]$InstallerFileName,
        [Parameter(Mandatory=$true)][string]$SoftwareName,
        [string[]]$InstallArgs = @("/passive", "/norestart", "/qn"),
        [string]$UninstallDisplayName,
        [string]$InstallDirectory
    )

    Write-Log "`nProcessing ZIPPED Package: $SoftwareName"
    
    if ($UninstallDisplayName) {
        $uninstallPaths = @("HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*", "HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*")
        if (Get-ItemProperty -Path $uninstallPaths -ErrorAction SilentlyContinue | Where-Object { $_.DisplayName -like "*$UninstallDisplayName*" }) {
            Write-Log "$SoftwareName is already installed. Skipping." -Level SUCCESS
            Record-TaskStatus -TaskName "Install: $SoftwareName" -Status "Skipped" -Details "Already Installed"
            return
        }
    }

    try {
        Write-Log "Downloading ZIP for $SoftwareName..."
        Invoke-WebRequest -Uri $Url -OutFile $ZipPath -UseBasicParsing -ErrorAction Stop

        Write-Log "Extracting ZIP..."
        if (Test-Path $ExtractFolder) { Remove-Item $ExtractFolder -Recurse -Force -ErrorAction SilentlyContinue }
        Expand-Archive -Path $ZipPath -DestinationPath $ExtractFolder -Force

        $installerPath = Join-Path $ExtractFolder $InstallerFileName
        if (-not (Test-Path $installerPath)) {
            Write-Log "Could not find expected installer ($InstallerFileName) inside the ZIP!" -Level ERROR
            Record-TaskStatus -TaskName "Install: $SoftwareName" -Status "Failed" -Details "Installer missing from ZIP"
            return
        }

        Write-Log "Running Installer from extracted folder..."
        $msiArgs = "/i `"$installerPath`" " + ($InstallArgs -join " ")
        if ($InstallDirectory) { $msiArgs += " INSTALLDIR=`"$InstallDirectory`"" }
        
        $process = if ($installerPath.ToLower().EndsWith(".msi")) {
            Start-Process "msiexec.exe" -ArgumentList $msiArgs -Wait -PassThru -ErrorAction Stop
        } else {
            Start-Process $installerPath -ArgumentList $InstallArgs -Wait -PassThru -ErrorAction Stop
        }

        if ($process.ExitCode -in @(0, 3010)) {
            Write-Log "$SoftwareName installed successfully." -Level SUCCESS
            Record-TaskStatus -TaskName "Install: $SoftwareName" -Status "Success" -Details $(if ($process.ExitCode -eq 3010) {"Reboot Required"} else {"Success"})
            if ($process.ExitCode -eq 3010) { $global:PendingRestart = $true }
            Remove-Item -Path $ExtractFolder -Recurse -Force -ErrorAction SilentlyContinue | Out-Null
            Write-Log "Retained ZIP package at $ZipPath" -Level INFO
        } else {
            Write-Log "Installation failed. Code: $($process.ExitCode)." -Level ERROR
            Record-TaskStatus -TaskName "Install: $SoftwareName" -Status "Failed" -Details "Exit Code: $($process.ExitCode)"
        }
    } catch {
        Write-Log "Error: $($_.Exception.Message)" -Level ERROR
        Record-TaskStatus -TaskName "Install: $SoftwareName" -Status "Failed" -Details "Exception Occurred"
    }
}

# --- 6. Execution Blocks ---

# A. FIPS Compliance
Write-Log "`n--- FIPS Compliance Check ---"
if (-not (Get-FipsRegistryStatus)) {
    Write-Log "FIPS disabled. Enabling in registry..."
    New-Item -Path "HKLM:\System\CurrentControlSet\Control\Lsa\FipsAlgorithmPolicy" -Force -ErrorAction SilentlyContinue | Out-Null
    Set-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Lsa\FipsAlgorithmPolicy" -Name "Enabled" -Value 1 -Force
    Record-TaskStatus -TaskName "FIPS Compliance" -Status "Success" -Details "Enabled (Reboot Required)"
    $global:PendingRestart = $true
} else {
    Write-Log "FIPS is already enabled." -Level SUCCESS
    Record-TaskStatus -TaskName "FIPS Compliance" -Status "Skipped" -Details "Already Enabled"
}

# B. Software Installations
Write-Log "`n--- Software Installation Phase ---"

Install-Package -Url "https://produpdates.blob.core.windows.net/web/Pre-requsite%20Application-%202026/Prerequsite%20softwares/CR13SP27MSI32_0-10010309.MSI?sp=racw&st=2026-02-27T09:23:31Z&se=2031-02-27T17:38:31Z&spr=https&sv=2024-11-04&sr=b&sig=6YdH%2BnpKFIi0REqIqnsexIyqJcZF7bWhYatNtMlE2f4%3D" -DestinationPath "$tempInstallPath\CR13SP27MSI32.msi" -SoftwareName "SAP Crystal Reports (32-bit)" -UninstallDisplayName "SAP Crystal Reports runtime engine for .NET Framework (32-bit)"
Install-Package -Url "https://produpdates.blob.core.windows.net/web/Pre-requsite%20Application-%202026/Prerequsite%20softwares/CR13SP27MSI64_0-10010309.MSI?sp=racw&st=2026-02-27T09:24:20Z&se=2031-02-27T17:39:20Z&spr=https&sv=2024-11-04&sr=b&sig=cootR9ALUq259FgQYpEg5VjQ1UBnz6RHftbTd6ZEJOk%3D" -DestinationPath "$tempInstallPath\CR13SP27MSI64.msi" -SoftwareName "SAP Crystal Reports (64-bit)" -UninstallDisplayName "SAP Crystal Reports runtime engine for .NET Framework (64-bit)"

Install-ZippedPackage -Url "https://produpdates.blob.core.windows.net/web/Pre-requsite%20Application-%202026/Prerequsite%20softwares/Phoenix%20Server%20Application%20Manager%202024%20-%20FIPS.zip?sp=racw&st=2026-02-27T09:27:17Z&se=2031-02-27T17:42:17Z&spr=https&sv=2024-11-04&sr=b&sig=GEfnpeBEBgmWhaetS14kgaDbdWhIgSLUC%2FtbzmhjLA8%3D" `
    -ZipPath "$phoenixAppManagerTempPath\PhoenixServer.zip" `
    -ExtractFolder "$phoenixAppManagerTempPath\PhoenixServerExtracted" `
    -InstallerFileName "PhoenixServerApplicationManager.msi" `
    -SoftwareName "Phoenix Server App Manager" `
    -UninstallDisplayName "Phoenix Server Application Manager" `
    -InstallDirectory "${phoenixAppManagerInstallDrive}:\Program Files (x86)\ProPhoenix\Server Application Manager"

Install-ZippedPackage -Url "https://produpdates.blob.core.windows.net/web/Pre-requsite%20Application-%202026/Prerequsite%20softwares/Phoenix%20Client%20Application%20Manager%202024%20FIPS.zip?sp=racw&st=2026-02-27T09:26:33Z&se=2031-02-27T17:41:33Z&spr=https&sv=2024-11-04&sr=b&sig=FxAf6Vwa0EHcwQrUGw5msSk5dwwN6z79emPPxe0ioik%3D" `
    -ZipPath "$phoenixAppManagerTempPath\PhoenixClient.zip" `
    -ExtractFolder "$phoenixAppManagerTempPath\PhoenixClientExtracted" `
    -InstallerFileName "PhoenixClientApplicationManager.msi" `
    -SoftwareName "Phoenix Client App Manager" `
    -UninstallDisplayName "Phoenix Client Application Manager" `
    -InstallDirectory "${phoenixAppManagerInstallDrive}:\Program Files (x86)\ProPhoenix\Client Application Manager"

Install-Package -Url "https://produpdates.blob.core.windows.net/web/Pre-requsite%20Application-%202026/Prerequsite%20softwares/dotnet-hosting-8.0.4-win.exe?sp=racw&st=2026-02-27T09:31:47Z&se=2031-02-27T17:46:47Z&spr=https&sv=2024-11-04&sr=b&sig=IOFkMN%2FXnkSPJwu6g4TpYq3PEJvbRXrAfAAB9CsLGs0%3D" -DestinationPath "$tempInstallPath\dotnet-hosting.exe" -SoftwareName "ASP.NET Core 8.0 Hosting" -InstallArgs @("/install", "/quiet", "/norestart") -UninstallDisplayName "Microsoft ASP.NET Core 8.0"

$accessDbUrl = if ([Environment]::Is64BitOperatingSystem) { "https://produpdates.blob.core.windows.net/web/Pre-requsite%20Application-%202026/Prerequsite%20softwares/accessdatabaseengine_X64.exe?sp=racw&st=2026-02-27T09:31:02Z&se=2031-02-27T17:46:02Z&spr=https&sv=2024-11-04&sr=b&sig=o59u4cO9EiPiKDFuklmql969kDJSwF3vdkA7zC8JeHw%3D" } else { "" }
if ($accessDbUrl) {
    Install-Package -Url $accessDbUrl -DestinationPath "$tempInstallPath\accessdb.exe" -SoftwareName "Access Database Engine" -InstallArgs @("/quiet", "/norestart") -UninstallDisplayName "Microsoft Access database engine"
}

Install-Package -Url "https://produpdates.blob.core.windows.net/web/Pre-requsite%20Application-%202026/Prerequsite%20softwares/SmartInspect-redist-3.3.0.10181.exe?sp=racw&st=2026-02-27T09:30:24Z&se=2031-02-27T17:45:24Z&spr=https&sv=2024-11-04&sr=b&sig=SHOlYfzuByqzueb6t8PBq2NAK5PYx8C%2BnA%2FMtYCHuOk%3D" -DestinationPath "$tempInstallPath\SmartInspect.exe" -SoftwareName "SmartInspect" -InstallArgs @("/silent") -UninstallDisplayName "SmartInspect"
Install-Package -Url "https://produpdates.blob.core.windows.net/web/Pre-requsite%20Application-%202026/Prerequsite%20softwares/MicrosoftEdgeWebView2RuntimeInstallerX64.exe?sp=racw&st=2026-02-27T09:25:43Z&se=2031-02-27T17:40:43Z&spr=https&sv=2024-11-04&sr=b&sig=XvBB8E02UxAqyz4DChoc0oeuIRtLtNehQYEPmbjfayU%3D" -DestinationPath "$tempInstallPath\WebView2.exe" -SoftwareName "Microsoft Edge WebView2 Runtime" -InstallArgs @("/silent", "/install") -UninstallDisplayName "Microsoft Edge WebView2 Runtime"
Install-Package -Url "https://produpdates.blob.core.windows.net/web/Pre-requsite%20Application-%202026/Prerequsite%20softwares/SQLSysClrTypes%2086.msi?sp=racw&st=2026-02-27T09:29:46Z&se=2031-02-27T17:44:46Z&spr=https&sv=2024-11-04&sr=b&sig=O6E2XCHkrlwLwVEAmM5a%2Be8gz3D%2BFZBswCpDNCEgyZ4%3D" -DestinationPath "$tempInstallPath\SQLSysClrTypes86.msi" -SoftwareName "SQL Sys CLR Types (x86)" -UninstallDisplayName "Microsoft SQL Server System CLR Types (x86)"
Install-Package -Url "https://produpdates.blob.core.windows.net/web/Pre-requsite%20Application-%202026/Prerequsite%20softwares/SQLSysClrTypes%2064.msi?sp=racw&st=2026-02-27T09:28:56Z&se=2031-02-27T17:43:56Z&spr=https&sv=2024-11-04&sr=b&sig=8w5Xqupkr2Et4A8lGo9d3aHjpZsi9VJ9dQ1lDwF7kJM%3D" -DestinationPath "$tempInstallPath\SQLSysClrTypes64.msi" -SoftwareName "SQL Sys CLR Types (x64)" -UninstallDisplayName "Microsoft SQL Server System CLR Types (x64)"
Install-Package -Url "https://produpdates.blob.core.windows.net/web/Pre-requsite%20Application-%202026/Prerequsite%20softwares/ReportViewer.msi?sp=racw&st=2026-02-27T09:28:16Z&se=2031-02-27T17:43:16Z&spr=https&sv=2024-11-04&sr=b&sig=VDZWUc0sIvMyE2DppDxuuCSvh6TlZTrhdiJ0C%2FXDiMs%3D" -DestinationPath "$tempInstallPath\ReportViewer.msi" -SoftwareName "Microsoft Report Viewer" -UninstallDisplayName "Microsoft Report Viewer Redistributable"
Install-Package -Url "https://produpdates.blob.core.windows.net/web/Pre-requsite%20Application-%202026/Prerequsite%20softwares/msoledbsql.msi?sp=racw&st=2026-02-27T09:32:21Z&se=2031-02-27T17:47:21Z&spr=https&sv=2024-11-04&sr=b&sig=MW6ExawS0YsZdjSO%2BOhY9ncYflrPgEona9aoqF3gn%2FU%3D" -DestinationPath "$tempInstallPath\msoledbsql.msi" -SoftwareName "OLE DB Driver for SQL" -InstallArgs @("/qn", "/norestart", "IACCEPTMSOLEDBSQLLICENSETERMS=YES") -UninstallDisplayName "Microsoft OLE DB Driver for SQL Server"

# C. Machine.config Optimization
Write-Log "`n--- Machine.config Optimization ---"
$numberOfCores = [Environment]::ProcessorCount

function Update-MachineConfig {
    param([string]$ConfigPath, [string]$BackupFolderPath, [string]$Label)
    try {
        if (!(Test-Path -path (Split-Path $ConfigPath))) { New-Item (Split-Path $ConfigPath) -Type Directory -Force | Out-Null }
        if (!(Test-Path -path $BackupFolderPath)) { New-Item $BackupFolderPath -Type Directory -Force | Out-Null }
        
        if (Test-Path $ConfigPath) { 
            $destinationFile = Join-Path $BackupFolderPath "machine.config"
            Copy-Item -Path $ConfigPath -Destination $destinationFile -Force 
        } else {
            $xmlText = "<?xml version=`"1.0`" encoding=`"utf-8`"?><configuration><system.web></system.web></configuration>"
            Set-Content -Path $ConfigPath -Value $xmlText -Encoding Ascii
        }

        [xml]$machineConfig = Get-Content $ConfigPath
        $sysWebNode = $machineConfig.SelectSingleNode("/configuration/system.web")
        $rootNode = $machineConfig.SelectSingleNode("/configuration")

        @("processModel", "httpRuntime") | ForEach-Object {
            $node = $sysWebNode.SelectSingleNode($_)
            if ($node) { $sysWebNode.RemoveChild($node) | Out-Null }
        }
        $sysNetNode = $rootNode.SelectSingleNode("system.net")
        if ($sysNetNode) { $rootNode.RemoveChild($sysNetNode) | Out-Null }

        $pModel = $machineConfig.CreateElement("processModel")
        $pModel.SetAttribute("autoConfig", "false")
        $pModel.SetAttribute("maxWorkerThreads", "100")
        $pModel.SetAttribute("maxIoThreads", "100")
        $pModel.SetAttribute("minWorkerThreads", "50")
        $pModel.SetAttribute("minIoThreads", "50")
        $sysWebNode.AppendChild($pModel) | Out-Null

        $hRuntime = $machineConfig.CreateElement("httpRuntime")
        $hRuntime.SetAttribute("minFreeThreads", (88 * $numberOfCores).ToString())
        $hRuntime.SetAttribute("minLocalRequestFreeThreads", (76 * $numberOfCores).ToString())
        $sysWebNode.AppendChild($hRuntime) | Out-Null

        $netXml = $machineConfig.CreateElement("system.net")
        $connMgmt = $machineConfig.CreateElement("connectionManagement")
        $addXml = $machineConfig.CreateElement("add")
        $addXml.SetAttribute("address", "*")
        $addXml.SetAttribute("maxconnection", (12 * $numberOfCores).ToString())
        $connMgmt.AppendChild($addXml) | Out-Null
        $netXml.AppendChild($connMgmt) | Out-Null
        $rootNode.AppendChild($netXml) | Out-Null

        $machineConfig.Save($ConfigPath)
        Record-TaskStatus -TaskName "Machine.config ($Label)" -Status "Success" -Details "Optimized for $numberOfCores Cores"
    } catch {
        Record-TaskStatus -TaskName "Machine.config ($Label)" -Status "Failed" -Details "XML Modification Error: $($_.Exception.Message)"
    }
}

Update-MachineConfig "C:\Windows\Microsoft.NET\Framework\v2.0.50727\Config\machine.config" "${backupDrive}:\PnxTemp\Machineconfig\32bit\V2" "v2 32-bit"
Update-MachineConfig "C:\Windows\Microsoft.NET\Framework64\v2.0.50727\Config\machine.config" "${backupDrive}:\PnxTemp\Machineconfig\64bit\V2" "v2 64-bit"
Update-MachineConfig "C:\Windows\Microsoft.NET\Framework\v4.0.30319\Config\machine.config" "${backupDrive}:\PnxTemp\Machineconfig\32bit\V4" "v4 32-bit"
Update-MachineConfig "C:\Windows\Microsoft.NET\Framework64\v4.0.30319\Config\machine.config" "${backupDrive}:\PnxTemp\Machineconfig\64bit\V4" "v4 64-bit"

# D. Page File Safety Limits
Write-Log "`n--- Page File Configuration ---"
try {
    $totalMemGB = (Get-CimInstance Win32_ComputerSystem).TotalPhysicalMemory / 1GB
    $calculatedSizeMB = [math]::Round(($totalMemGB / 2) + $totalMemGB) * 1024
    $initialSizeMB = if ($calculatedSizeMB -gt 32768) { 32768 } else { $calculatedSizeMB }
    $maximumSizeMB = $initialSizeMB + 64
    $desiredValueData = "C:\pagefile.sys $initialSizeMB $maximumSizeMB"

    Set-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management' -Name 'PagingFiles' -Value $desiredValueData -Force
    Record-TaskStatus -TaskName "Page File Setup" -Status "Success" -Details "Set to $initialSizeMB MB"
} catch {
    Record-TaskStatus -TaskName "Page File Setup" -Status "Failed" -Details "Registry update failed: $($_.Exception.Message)"
}

# E. Log Cleaner Task
Write-Log "`n--- IIS Log Cleaner Task ---"
$logCleanerZipUrl = "https://produpdates.blob.core.windows.net/web/Pre-requsite%20Application-%202026/Prerequsite%20softwares/LogCleaner.zip?sp=racw&st=2026-02-27T09:24:58Z&se=2031-02-27T17:39:58Z&spr=https&sv=2024-11-04&sr=b&sig=f1sLM0MZcRaRtP9Zx8V0FfEHcO0Kpv88NOceFb50640%3D"
$taskDestPath = "${installDrive}:\ProPhoenix\Tools\LogCleaner"
$zipDest = "$tempInstallPath\LogCleaner.zip"

if (-not (Test-Path $taskDestPath)) { New-Item $taskDestPath -ItemType Directory -Force | Out-Null }

try {
    Invoke-WebRequest -Uri $logCleanerZipUrl -OutFile $zipDest -UseBasicParsing -ErrorAction Stop
    Expand-Archive -Path $zipDest -DestinationPath $taskDestPath -Force
    Remove-Item $zipDest -Force -ErrorAction SilentlyContinue | Out-Null

    $action = New-ScheduledTaskAction -Execute 'cmd.exe' -Argument "/c `"$taskDestPath\CleanLogs.bat`""
    $trigger = New-ScheduledTaskTrigger -Daily -At "4:00 AM"
    $settings = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -StartWhenAvailable -MultipleInstances Parallel
    $principal = New-ScheduledTaskPrincipal -GroupId "BUILTIN\Administrators" -RunLevel Highest

    Register-ScheduledTask -TaskName "Clean Logs in IIS" -Action $action -Trigger $trigger -Settings $settings -Principal $principal -Description "IIS Log Cleaner" -Force | Out-Null
    Record-TaskStatus -TaskName "Log Cleaner Task" -Status "Success" -Details "Task Registered"
} catch {
    Record-TaskStatus -TaskName "Log Cleaner Task" -Status "Failed" -Details "Setup Error: $($_.Exception.Message)"
}

# F. Firewall Ports (Phase 1 Initial Pass)
Write-Log "`n--- Firewall Configuration ---"
$requiredPorts = @(80, 443, 8888, 8889, 8080, 6666, 6667, 8245, 7005, 6990, 9998, 8090, 3000, 5555, 9600, 1433, 8081, 8182, 8181)
$fwStatus = @{ Created = 0; Exists = 0; Failed = 0 }

foreach ($port in $requiredPorts) {
    foreach ($dir in @("Inbound", "Outbound")) {
        $ruleName = "ProPhoenix Port $port ($dir)"
        
        if (Get-NetFirewallRule -DisplayName $ruleName -ErrorAction SilentlyContinue) {
            Write-Log "Rule already exists: $ruleName" -Level INFO
            $fwStatus.Exists++
        } else {
            try {
                Write-Log "Creating rule: $ruleName" -Level ADDING
                New-NetFirewallRule -DisplayName $ruleName -Direction $dir -Action Allow -Protocol TCP -LocalPort $port -Profile Any -ErrorAction Stop | Out-Null
                $fwStatus.Created++
            } catch {
                Write-Log "Failed to create rule: $ruleName - $($_.Exception.Message)" -Level ERROR
                $fwStatus.Failed++
            }
        }
    }
}
Record-TaskStatus -TaskName "Firewall Rules" -Status "Completed" -Details "Created: $($fwStatus.Created), Existed: $($fwStatus.Exists), Failed: $($fwStatus.Failed)"


# G. Windows Update Policy
Write-Log "`n--- Windows Update Policy ---"
try {
    $auPath = "HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU"
    if (!(Test-Path $auPath)) { New-Item $auPath -Force | Out-Null }
    Set-ItemProperty -Path $auPath -Name "AUOptions" -Value 3 -Force
    Remove-ItemProperty -Path $auPath -Name "NoAutoUpdate" -Force -ErrorAction SilentlyContinue | Out-Null

    & gpupdate /force | Out-Null
    Restart-Service -Name wuauserv -Force -ErrorAction SilentlyContinue | Out-Null
    Record-TaskStatus -TaskName "Windows Update" -Status "Success" -Details "Set to Download Only"
} catch {
    Record-TaskStatus -TaskName "Windows Update" -Status "Failed" -Details "Policy Error: $($_.Exception.Message)"
}

# --- 7. Final Status Report (Phase 1) ---
Write-Host "`n=========================================================================" -ForegroundColor Cyan
Write-Host "                       PHASE 1 EXECUTION SUMMARY                           " -ForegroundColor Cyan
Write-Host "=========================================================================`n" -ForegroundColor Cyan

foreach ($task in $global:ExecutionSummary) {
    $color = switch ($task.Status) {
        "Success"   { "Green" }
        "Completed" { "Green" }
        "Skipped"   { "DarkYellow" }
        "Failed"    { "Red" }
        default     { "White" }
    }
    
    $paddedTask = $task.Task.PadRight(35)
    $paddedStatus = $task.Status.PadRight(10)
    Write-Host "$paddedTask | $paddedStatus | $($task.Details)" -ForegroundColor $color
}


# ==============================================================================
# --- [PHASE 1.5] UNIVERSAL IIS CONFIGURATION & DEPLOYMENT ---
# ==============================================================================

Write-Host "`n=========================================================================" -ForegroundColor Cyan
Write-Host "                PHASE 1.5: IIS FEATURE DEPLOYMENT                          " -ForegroundColor Cyan
Write-Host "=========================================================================" -ForegroundColor Cyan

$osInfo = Get-CimInstance -ClassName Win32_OperatingSystem
$isServer = $osInfo.ProductType -ne 1 # 1 = Workstation (Win 10/11), 2/3 = Server

Write-Host "  OS Detected: $($osInfo.Caption)" -ForegroundColor Cyan
Write-Host "-------------------------------------------------------------------------`n" -ForegroundColor Cyan

# --- SERVER OS EXECUTION PATH ---
if ($isServer) {
    
    # Batch 1: Modern Features (Safe, high-speed installation)
    $modernFeatures = @(
        "Web-Server", "Web-WebServer", "Web-Common-Http", "Web-Static-Content",
        "Web-Default-Doc", "Web-Dir-Browsing", "Web-Http-Errors", "Web-Http-Redirect",
        "Web-Ftp-Server", "Web-Ftp-Service", "Web-Asp-Net45", "Web-Net-Ext45", 
        "Web-ISAPI-Ext", "Web-ISAPI-Filter", "Web-AppInit", "Web-Asp", "Web-CGI",
        "Web-Http-Logging", "Web-Log-Libraries", "Web-Request-Monitor", "Web-Http-Tracing",
        "Web-Basic-Auth", "Web-Digest-Auth", "Web-Windows-Auth",
        "Web-Stat-Compression", "Web-Dyn-Compression",
        "Web-Mgmt-Console", "Web-Metabase", "Web-WMI", "Web-Lgcy-Mgmt-Console",
        "NET-Framework-45-Core", "NET-Framework-45-ASPNET", 
        "NET-WCF-HTTP-Activation45", "NET-WCF-TCP-PortSharing45"
    )

    # Batch 2: Legacy Features (Isolated to prevent WSUS rollback)
    $legacyFeatures = @("NET-Framework-Core", "NET-Http-Activation", "Web-Asp-Net", "Web-Net-Ext")
    $allServerFeatures = $modernFeatures + $legacyFeatures

    # --- Install Batch 1 ---
    Write-Host "⏳ [Phase 1.5A] Installing Modern IIS Features..." -ForegroundColor Yellow
    try {
        $result1 = Install-WindowsFeature -Name $modernFeatures -ErrorAction Stop
        if ($result1.RestartNeeded -eq 'Yes') { $global:PendingRestart = $true }
    } catch {
        Write-Warning "Phase 1.5A encountered an issue: $_"
    }

    # --- Install Batch 2 ---
    Write-Host "⏳ [Phase 1.5B] Attempting Legacy .NET 3.5 Features..." -ForegroundColor Yellow
    try {
        $result2 = Install-WindowsFeature -Name $legacyFeatures -ErrorAction Stop
        if ($result2.RestartNeeded -eq 'Yes') { $global:PendingRestart = $true }
    } catch {
        Write-Warning "Legacy .NET 3.5 blocked by WSUS (0x800f0954). Will require offline source later."
    }

    # --- Generate Status Report ---
    Write-Host "`n--- IIS Feature Installation Status ---" -ForegroundColor Cyan
    
    $featureStatus = Get-WindowsFeature -Name $allServerFeatures
    foreach ($feature in $featureStatus) {
        if ($feature.InstallState -eq "Installed") {
            Write-Host "  [✔] $($feature.DisplayName)" -ForegroundColor Green
        } else {
            Write-Host "  [❌] $($feature.DisplayName) (Missing/Blocked)" -ForegroundColor Red
        }
    }
} else {
    # --- CLIENT OS (WINDOWS 10/11) EXECUTION PATH ---
    Write-Host "⏳ Configuring Windows Client IIS Features..." -ForegroundColor Yellow
    
    # Client features map to different names and use DISM/OptionalFeatures
    $clientFeatures = @(
        "IIS-WebServerRole", "IIS-WebServer", "IIS-CommonHttpFeatures", "IIS-StaticContent", 
        "IIS-DefaultDocument", "IIS-DirectoryBrowsing", "IIS-HttpErrors", "IIS-HttpRedirect", 
        "IIS-FTPServer", "IIS-FTPSvc", "IIS-ASPNET45", "IIS-NetFxExtensibility45", 
        "IIS-ISAPIExtensions", "IIS-ISAPIFilter", "IIS-ApplicationInit", "IIS-ASP", "IIS-CGI", 
        "IIS-HttpLogging", "IIS-LoggingLibraries", "IIS-RequestMonitor", "IIS-HttpTracing", 
        "IIS-BasicAuthentication", "IIS-DigestAuthentication", "IIS-WindowsAuthentication", 
        "IIS-HttpCompressionStatic", "IIS-HttpCompressionDynamic", "IIS-ManagementConsole", 
        "IIS-IIS6ManagementCompatibility", "IIS-Metabase", "IIS-WMICompatibility", "IIS-LegacySnapIn",
        "WCF-HTTP-Activation45", "WCF-TCP-PortSharing45"
    )

    # Note: Client OS occasionally uses NetFx3 for .NET 3.5, which we will separate
    $clientLegacy = @("NetFx3", "IIS-ASPNET", "IIS-NetFxExtensibility")
    $allClientFeatures = $clientFeatures + $clientLegacy

    # Enable Modern Client Features
    foreach ($feature in $clientFeatures) {
        $res = Enable-WindowsOptionalFeature -Online -FeatureName $feature -All -NoRestart -ErrorAction SilentlyContinue
        if ($res.RestartNeeded -eq $true) { $global:PendingRestart = $true }
    }

    # Enable Legacy Client Features
    foreach ($feature in $clientLegacy) {
        $res = Enable-WindowsOptionalFeature -Online -FeatureName $feature -All -NoRestart -ErrorAction SilentlyContinue
        if ($res.RestartNeeded -eq $true) { $global:PendingRestart = $true }
    }

    # --- Generate Status Report ---
    Write-Host "`n--- IIS Feature Installation Status ---" -ForegroundColor Cyan

    foreach ($feature in $allClientFeatures) {
        $state = (Get-WindowsOptionalFeature -Online -FeatureName $feature).State
        if ($state -eq "Enabled") {
            Write-Host "  [✔] $feature" -ForegroundColor Green
        } else {
            Write-Host "  [❌] $feature (Missing/Blocked)" -ForegroundColor Red
        }
    }
}

# --- FINALIZE IIS SERVICES ---
Write-Host "`n--- Starting IIS Services ---" -ForegroundColor Cyan

$services = @("W3SVC", "IISADMIN", "ftpsvc")
foreach ($service in $services) {
    if (Get-Service -Name $service -ErrorAction SilentlyContinue) {
        Set-Service -Name $service -StartupType Automatic -ErrorAction SilentlyContinue
        Start-Service -Name $service -ErrorAction SilentlyContinue
        Write-Host "  [✔] $service is configured to Automatic and Running." -ForegroundColor Green
    } else {
        Write-Host "  [⚠️] $service is not present on this system." -ForegroundColor DarkYellow
    }
}

# ==============================================================================
# --- [PHASE 2] CONFIGURE BI-DIRECTIONAL FIREWALL (SILENT FAST RAM CHECK) ---
# ==============================================================================

Write-Host "`n=========================================================================" -ForegroundColor Cyan
Write-Host "                PHASE 2: BI-DIRECTIONAL FIREWALL INTEGRITY                 " -ForegroundColor Cyan
Write-Host "=========================================================================`n" -ForegroundColor Cyan

$directions = @("Inbound", "Outbound")

# Read current rules into memory once to eliminate processing lag completely
$existingRules = Get-NetFirewallRule -ErrorAction SilentlyContinue | Select-Object -ExpandProperty DisplayName

foreach ($port in $requiredPorts) {
    foreach ($direction in $directions) {
        $ruleName = "ProPhoenix Port $port ($direction)"
        
        if ($existingRules -notcontains $ruleName) {
            try {
                New-NetFirewallRule -DisplayName $ruleName `
                                    -Direction $direction `
                                    -Action Allow `
                                    -Protocol TCP `
                                    -LocalPort $port `
                                    -Profile Any -ErrorAction Stop | Out-Null
                Write-Host "  [FIXED] Auto-configured missing rule: $ruleName" -ForegroundColor Yellow
            } catch {
                Write-Warning "Failed to auto-configure firewall rule for port $port ($direction). Reason: $($_.Exception.Message)"
            }
        }
    }
}

# ==============================================================================
# --- [PHASE 3] DETAILED ENVIRONMENT VERIFICATION AUDIT ---
# ==============================================================================

Write-Host "`n=========================================================================" -ForegroundColor Cyan
Write-Host "            PHASE 3: DETAILED STEP-BY-STEP INSTALLATION AUDIT" -ForegroundColor Cyan
Write-Host "=========================================================================" -ForegroundColor Cyan

# Gather complete local inventory string values to prevent character truncation
$inventory = Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*", "HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\Uninstall\*" -ErrorAction SilentlyContinue

# --- [STEP 1] FIPS COMPLIANCE ---
Write-Host "`n[STEP 1] FIPS Compliance Check" -ForegroundColor Yellow
$fips = (Get-ItemProperty -Path "HKLM:\System\CurrentControlSet\Control\Lsa\FipsAlgorithmPolicy" -Name "Enabled" -ErrorAction SilentlyContinue).Enabled
if ($fips -eq 1) { 
    Write-Host "  [SUCCESS] FIPS is ENABLED in registry." -ForegroundColor Green 
} else {
    Write-Host "  [FAILURE] FIPS is NOT enabled. Reason: Registry key 'Enabled' does not equal 1." -ForegroundColor Red
}

# --- [STEP 2] PREREQUISITE SOFTWARE ---
Write-Host "`n[STEP 2] Prerequisite Software Check" -ForegroundColor Yellow
$appsToCheck = @(
    @{ Key="SAP Crystal Reports runtime"; Search="SAP Crystal Reports runtime" },
    @{ Key="Server Application Manager"; Search="Server Application Manager" },
    @{ Key="Client Application Manager"; Search="Client Application Manager" },
    @{ Key="Adobe Reader"; Search="Adobe Reader" },
    @{ Key="ASP.NET Core 8.0"; Search="ASP.NET Core 8.0" },
    @{ Key="Access database engine"; Search="Access database engine" },
    @{ Key="SmartInspect"; Search="SmartInspect" },
    @{ Key="WebView2 Runtime"; Search="WebView2" },
    @{ Key="SQL Server System CLR Types"; Search="System CLR Types for SQL Server" }, 
    @{ Key="Report Viewer"; Search="Report Viewer" },
    @{ Key="OLE DB Driver"; Search="OLE DB Driver" }
)

foreach ($app in $appsToCheck) {
    $matches = $inventory | Where-Object { $_.DisplayName -like "*$($app.Search)*" }
    if ($matches) {
        foreach ($m in $matches) {
            Write-Host "  [SUCCESS] Found: $($m.DisplayName)" -ForegroundColor Green
            Write-Host "            Version: $($m.DisplayVersion)" -ForegroundColor Gray
        }
    } else {
        Write-Host "  [FAILURE] MISSING: $($app.Key). Reason: Uninstall registry key not found matching pattern." -ForegroundColor Red
    }
}

# --- [STEP 3] MACHINE.CONFIG VALIDATION ---
Write-Host "`n[STEP 3] .NET Machine.config XML Structure Audit" -ForegroundColor Yellow
$configs = @(
    "C:\Windows\Microsoft.NET\Framework\v2.0.50727\Config\machine.config",
    "C:\Windows\Microsoft.NET\Framework64\v2.0.50727\Config\machine.config",
    "C:\Windows\Microsoft.NET\Framework\v4.0.30319\Config\machine.config",
    "C:\Windows\Microsoft.NET\Framework64\v4.0.30319\Config\machine.config"
)
foreach ($path in $configs) {
    if (Test-Path $path) {
        try {
            [xml]$xml = Get-Content $path -ErrorAction SilentlyContinue
            $node = $xml.SelectSingleNode("//processModel[@autoConfig='false']")
            if ($node) { 
                Write-Host "  [SUCCESS] Optimization verified: $path" -ForegroundColor Green 
            } else { 
                Write-Host "  [FAILURE] Optimization missing or incorrect in: $path. Reason: <processModel autoConfig='false'> XML node absent." -ForegroundColor Red 
            }
        } catch {
            Write-Host "  [ERROR] Failed parsing XML file: $path. Reason: Invalid XML structure or file locked." -ForegroundColor Red
        }
    } else { 
        Write-Host "  [SKIP] Path not found: $path (Framework version may not be installed)." -ForegroundColor Gray 
    }
}

# --- [STEP 4] PAGEFILE STRUCTURAL EVALUATION ---
Write-Host "`n[STEP 4] Windows Virtual Memory Pagefile Allocation Audit" -ForegroundColor Yellow
try {
    $pagingFiles = (Get-ItemProperty -Path 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management' -Name 'PagingFiles' -ErrorAction SilentlyContinue).PagingFiles
    if ($pagingFiles) {
        Write-Host "  [SUCCESS] Active Paging Configuration Verified: $pagingFiles" -ForegroundColor Green
    } else {
        Write-Host "  [FAILURE] Page file settings are NOT configured as desired. Reason: Registry property 'PagingFiles' returned null." -ForegroundColor Red
    }
} catch {
    Write-Host "  [ERROR] Failed to query pagefile memory registry attributes. Reason: Access denied or path missing." -ForegroundColor Red
}

# --- [STEP 5] FIREWALL COMPLIANCE SUMMARY ---
Write-Host "`n[STEP 5] ProPhoenix Firewall Rules Audit" -ForegroundColor Yellow

$freshRules = Get-NetFirewallRule -ErrorAction SilentlyContinue | Select-Object -ExpandProperty DisplayName
$missingRules = @()

foreach ($port in $requiredPorts) {
    foreach ($direction in $directions) {
        $ruleName = "ProPhoenix Port $port ($direction)"
        if ($freshRules -notcontains $ruleName) {
            $missingRules += "Port $port ($direction)"
        }
    }
}

if ($missingRules.Count -eq 0) {
    Write-Host "  [SUCCESS] Firewall is fully configured." -ForegroundColor Green
} else {
    Write-Host "  [FAILURE] Firewall is NOT fully configured. Reason: NetFirewallRules missing." -ForegroundColor Red
    foreach ($missing in $missingRules) {
        Write-Host "    -> Missing: $missing" -ForegroundColor Yellow
    }
}

# --- [STEP 6] INFRASTRUCTURE & MAINTENANCE POLICY ---
Write-Host "`n[STEP 6] Infrastructure & Automation System Policy Check" -ForegroundColor Yellow

$task = Get-ScheduledTask -TaskName "Clean Logs in IIS" -ErrorAction SilentlyContinue
if ($task) { 
    Write-Host "  [SUCCESS] IIS Log Cleaner Task Registered." -ForegroundColor Green 
    Write-Host "            Current Status: $($task.State)" -ForegroundColor Gray
} else { 
    Write-Host "  [FAILURE] Log Cleaner Automation Task not found. Reason: 'Clean Logs in IIS' absent from Task Scheduler." -ForegroundColor Red 
}

$logCleanerPath = "${installDrive}:\ProPhoenix\Tools\LogCleaner\CleanLogs.bat"
if (Test-Path $logCleanerPath) {
    Write-Host "  [SUCCESS] Log Cleaner script active at location: $logCleanerPath" -ForegroundColor Green
} else {
    Write-Host "  [FAILURE] Log cleaner batch file not found at: $logCleanerPath." -ForegroundColor Red
}

$au = (Get-ItemProperty -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate\AU" -Name "AUOptions" -ErrorAction SilentlyContinue).AUOptions
if ($au -eq 3) { 
    Write-Host "  [SUCCESS] SConfig Update Policy: Download Only Verified." -ForegroundColor Green 
} else {
    Write-Host "  [FAILURE] SConfig Update Policy Incorrect (Value: $au). Reason: Registry 'AUOptions' does not equal 3." -ForegroundColor Red
}

# --- [STEP 7] IIS FEATURES & ROLES GLOBAL AUDIT ---
Write-Host "`n[STEP 7] Global IIS Features & Server Roles Audit" -ForegroundColor Yellow

$iisFeatures = @(
    @{ Name="Web-Server"; Desc="IIS Base Engine" },
    @{ Name="Web-Static-Content"; Desc="Common HTTP Features: Static Content" },
    @{ Name="Web-Default-Doc"; Desc="Common HTTP Features: Default Document" },
    @{ Name="Web-Dir-Browsing"; Desc="Common HTTP Features: Directory Browsing" },
    @{ Name="Web-Http-Errors"; Desc="Common HTTP Features: HTTP Errors" },
    @{ Name="Web-Http-Redirect"; Desc="Common HTTP Features: HTTP Redirection" },
    @{ Name="Web-Asp-Net45"; Desc="Application Development: ASP.NET 4.5/4.8" },
    @{ Name="Web-Net-Ext45"; Desc="Application Development: .NET Extensibility" },
    @{ Name="Web-CGI"; Desc="Application Development: CGI" },
    @{ Name="Web-ISAPI-Ext"; Desc="Application Development: ISAPI Extensions" },
    @{ Name="Web-ISAPI-Filter"; Desc="Application Development: ISAPI Filters" },
    @{ Name="Web-Http-Logging"; Desc="Health and Diagnostics: HTTP Logging" },
    @{ Name="Web-Log-Libraries"; Desc="Health and Diagnostics: Logging Tools" },
    @{ Name="Web-Request-Monitor"; Desc="Health and Diagnostics: Request Monitor" },
    @{ Name="Web-Http-Tracing"; Desc="Health and Diagnostics: Tracing" },
    @{ Name="Web-Basic-Auth"; Desc="Security: Basic Authentication" },
    @{ Name="Web-Windows-Auth"; Desc="Security: Windows Authentication" },
    @{ Name="Web-Digest-Auth"; Desc="Security: Digest Authentication" },
    @{ Name="Web-Stat-Compression"; Desc="Performance: Static Content Compression" },
    @{ Name="Web-Dyn-Compression"; Desc="Performance: Dynamic Content Compression" },
    @{ Name="Web-Mgmt-Console"; Desc="Management Tools: IIS Management Console" },
    @{ Name="Web-Metabase"; Desc="IIS 6 Compatibility: IIS 6 Metabase Compatibility" }, 
    @{ Name="Web-WMI"; Desc="IIS 6 Compatibility: IIS 6 WMI Compatibility" },
    @{ Name="Web-Lgcy-Mgmt-Console"; Desc="IIS 6 Compatibility: IIS 6 Management Console" },
    @{ Name="Web-Ftp-Server"; Desc="FTP Server Engine" }
)

try {
    Import-Module ServerManager -ErrorAction SilentlyContinue
    $systemFeatures = Get-WindowsFeature

    $missingFeaturesCount = 0
    foreach ($feature in $iisFeatures) {
        $currentStatus = $systemFeatures | Where-Object { $_.Name -eq $feature.Name }
        if ($currentStatus -and $currentStatus.Installed) {
            Write-Host "  [SUCCESS] Installed: $($feature.Desc)" -ForegroundColor Green
        } else {
            Write-Host "  [FAILURE] MISSING ROLE: $($feature.Desc) ($($feature.Name)). Reason: Windows feature not installed." -ForegroundColor Red
            $missingFeaturesCount++
        }
    }

    Write-Host "`n----------------------------------------------------------" -ForegroundColor Gray
    if ($missingFeaturesCount -eq 0) {
        Write-Host "  -> Global Environment Check: IIS is fully optimized for all production environments." -ForegroundColor Green
    } else {
        Write-Host "  -> Global Environment Check: $missingFeaturesCount required IIS roles are missing." -ForegroundColor Yellow
        Write-Host "     Run: 'Install-WindowsFeature <Feature-Name>' to resolve omissions." -ForegroundColor Gray
    }
} catch {
    Write-Host "  [ERROR] ServerManager module is unavailable. Skipping structural IIS role query. Reason: Module missing or incompatible OS." -ForegroundColor Red
}

Write-Host "`n=========================================================================" -ForegroundColor Cyan
Write-Host "                 AUDIT & INSTALL COMPLETE" -ForegroundColor Cyan
Write-Host "=========================================================================" -ForegroundColor Cyan

if ($global:PendingRestart) {
    Write-Host "`n⚠️ ATTENTION: A system restart is REQUIRED for all components and IIS features to fully activate." -ForegroundColor Yellow
    Write-Host "⚠️ The system will NOT restart automatically." -ForegroundColor Yellow
} else {
    Write-Host "`nA system reboot is highly recommended to finalize configurations." -ForegroundColor Cyan
}

Write-Host "`n🚀 Script execution is complete." -ForegroundColor Cyan
Read-Host -Prompt "Press Enter to close the terminal"
[Environment]::Exit(0)