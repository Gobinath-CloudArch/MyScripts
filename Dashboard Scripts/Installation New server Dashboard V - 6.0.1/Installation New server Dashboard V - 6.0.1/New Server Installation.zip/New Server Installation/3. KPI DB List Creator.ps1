Clear-host

Write-Host "`n==========================================" -ForegroundColor Cyan
Write-Host "   PROVISIONING SQL SCRIPT GENERATOR" -ForegroundColor Cyan
Write-Host "==========================================`n" -ForegroundColor Cyan

# ==========================================
# 1. Prompt for Agency Name
# ==========================================
Write-Host "--- Step 1: Agency Details ---" -ForegroundColor Cyan
$agencyName = Read-Host "Please enter the Agency Name (e.g., NJRWBSVR01)"
Write-Host ""

# ==========================================
# 2. Prompt for Hostname/IP Address
# ==========================================
Write-Host "--- Step 2: Network Configuration ---" -ForegroundColor Cyan
$ipAddress = Read-Host "Please enter the CAD/NCIC Hostname or IP Address (e.g., NJ-RWB-SVR-01)"
Write-Host ""

# ==========================================
# 3. Prompt for Access URLs
# ==========================================
Write-Host "--- Step 3: Access URLs ---" -ForegroundColor Cyan
Write-Host "LocalHost is added by default. Enter additional URLs one at a time."
Write-Host "Press [Enter] on an empty line when you are finished."
$urls = @("LocalHost")
while ($true) {
    $urlInput = Read-Host "Enter an Access URL (or press Enter to finish)"
    if ([string]::IsNullOrWhiteSpace($urlInput)) { 
        break 
    }
    $urls += $urlInput
}
Write-Host ""

# ==========================================
# 4. Prompt for Setup Type & DB Names
# ==========================================
Write-Host "--- Step 4: Database Configuration ---" -ForegroundColor Cyan
Write-Host "Please select the provisioning setup type:"
Write-Host "1. Demo setup"
Write-Host "2. Customer setup"
Write-Host "3. Internal setup"
Write-Host ""

$setupCategory = ""
$dbConfigs = @()

while ($setupCategory -eq "") {
    $setupChoice = Read-Host "Enter the number (1-3)"
    
    if ($setupChoice -eq "1" -or $setupChoice -eq "3") { 
        # --- AUTOMATED DEMO / INTERNAL SETUP ---
        $setupCategory = if ($setupChoice -eq "1") { "Demo setup" } else { "Internal setup" }
        $env = if ($setupChoice -eq "1") { "Demo" } else { "Live" }
        $runMode = if ($env -eq "Live") { 1 } else { 2 }
        
        Write-Host "`nAuto-generating $env databases for $setupCategory..." -ForegroundColor Green
        
        $dbConfigs += [PSCustomObject]@{ DBName = "Law $env"; Environment = $env; Product = "Police"; ProductID = 1; RunMode = $runMode }
        $dbConfigs += [PSCustomObject]@{ DBName = "Fire $env"; Environment = $env; Product = "Fire"; ProductID = 2; RunMode = $runMode }
        $dbConfigs += [PSCustomObject]@{ DBName = "IA $env"; Environment = $env; Product = "IA"; ProductID = 7; RunMode = $runMode }
        $dbConfigs += [PSCustomObject]@{ DBName = "CAD $env"; Environment = $env; Product = "CAD"; ProductID = 4; RunMode = $runMode }
    }
    elseif ($setupChoice -eq "2") { 
        # --- CUSTOMER SETUP ---
        $setupCategory = "Customer setup" 
        
        # 4a. Prompt for Products
        Write-Host "`nWhich products do you need to create DB names for?" -ForegroundColor Cyan
        Write-Host "1. Law, CAD"
        Write-Host "2. Law, CAD, Fire"
        Write-Host "3. Law, CAD, Fire, IA"
        Write-Host "4. Law, CAD, IA"
        Write-Host ""
        
        $productChoice = ""
        while ($productChoice -notmatch "^[1-4]$") {
            $productChoice = Read-Host "Enter the number (1-4)"
            if ($productChoice -notmatch "^[1-4]$") {
                Write-Host "Invalid choice. Please enter 1, 2, 3, or 4." -ForegroundColor Yellow
            }
        }

        # 4b. Prompt for CAD Server Type
        Write-Host "`nIs this setup Primary & Secondary?" -ForegroundColor Cyan
        Write-Host "1. Yes"
        Write-Host "2. No"
        Write-Host ""
        $cadSetup = ""
        while ($cadSetup -eq "") {
            $cadChoice = Read-Host "Enter the number (1-2)"
            if ($cadChoice -eq "1") { $cadSetup = "NLB" }
            elseif ($cadChoice -eq "2") { $cadSetup = "Single" }
            else { Write-Host "Invalid choice. Please enter 1 or 2." -ForegroundColor Yellow }
        }
        Write-Host ""

        # Auto-generate Live and Training environments based on product choice
        $envs = @("Live", "Training")
        
        foreach ($env in $envs) {
            $runMode = if ($env -eq "Live") { 1 } else { 2 }
            
            # Law is in all options
            $dbConfigs += [PSCustomObject]@{ DBName = "Law $env"; Environment = $env; Product = "Police"; ProductID = 1; RunMode = $runMode }
            
            # Fire is in options 2 and 3
            if ($productChoice -eq "2" -or $productChoice -eq "3") {
                $dbConfigs += [PSCustomObject]@{ DBName = "Fire $env"; Environment = $env; Product = "Fire"; ProductID = 2; RunMode = $runMode }
            }
            
            # IA is in options 3 and 4
            if ($productChoice -eq "3" -or $productChoice -eq "4") {
                $dbConfigs += [PSCustomObject]@{ DBName = "IA $env"; Environment = $env; Product = "IA"; ProductID = 7; RunMode = $runMode }
            }

            # CAD is in all options
            if ($cadSetup -eq "NLB") {
                $dbConfigs += [PSCustomObject]@{ DBName = "CAD Primary $env"; Environment = $env; Product = "CAD"; ProductID = 4; RunMode = $runMode }
                $dbConfigs += [PSCustomObject]@{ DBName = "CAD Secondary $env"; Environment = $env; Product = "CAD"; ProductID = 4; RunMode = $runMode }
            } else {
                $dbConfigs += [PSCustomObject]@{ DBName = "CAD $env"; Environment = $env; Product = "CAD"; ProductID = 4; RunMode = $runMode }
            }
        }
    }
    else { Write-Host "Invalid choice. Please enter 1, 2, or 3." -ForegroundColor Yellow }
}

# Show the user a crisp summary of what was parsed/generated
Write-Host "`n--- Setup Summary ($setupCategory) ---" -ForegroundColor Green
$dbConfigs | Format-Table DBName, Environment, Product, ProductID -AutoSize
Write-Host "------------------------------------`n" -ForegroundColor Green

# ==========================================
# 5. Locate Web.config & Fetch DBConnStr
# ==========================================
Write-Host "--- Step 5: Locating Connection String ---" -ForegroundColor Cyan
$drives = Get-PSDrive -PSProvider FileSystem | Select-Object -ExpandProperty Root
$webConfigPath = $null

foreach ($drive in $drives) {
    $testPath = Join-Path $drive "Program Files\ProPhoenix\Provision Manager\web.config"
    if (Test-Path $testPath) {
        $webConfigPath = $testPath
        break
    }
}

$dbConnStrValue = ""
if ($webConfigPath) {
    Write-Host "Found web.config at: $webConfigPath" -ForegroundColor Green
    $configContent = Get-Content -Path $webConfigPath -Raw
    if ($configContent -match 'key="KPIMast_ConnStr"\s+value="([^"]+)"') {
        $dbConnStrValue = $matches[1]
    } else {
        $dbConnStrValue = "CONNECTION_STRING_NOT_FOUND"
    }
} else {
    Write-Host "Could not find 'Provision Manager\web.config' on any drive." -ForegroundColor Yellow
    $dbConnStrValue = "WEB_CONFIG_NOT_FOUND"
}
Write-Host ""

# ==========================================
# 6. Generate the SQL Script (NOW WITH CONFLICT HANDLING)
# ==========================================
Write-Host "--- Generating SQL Script ---" -ForegroundColor Cyan

$sql = @"
-- Setup Type: $setupCategory
-- Step 1: Declare variables
DECLARE @AgencyID VARCHAR(50);
DECLARE @DBConnStr NVARCHAR(MAX);
DECLARE @IPAddress NVARCHAR(100) = '$ipAddress'; 

-- Access URLs
"@

for ($i = 0; $i -lt $urls.Count; $i++) {
    $sql += "`nDECLARE @AccessURL$($i+1) NVARCHAR(100) = '$($urls[$i])';"
}

$sql += @"


-- Step 2: Fetch Agency ID and set DB connection string
SELECT @AgencyID = AgencyID
FROM dbo.PRVAgency
WHERE AgencyName = '$agencyName'; 

SET @DBConnStr = '$dbConnStrValue';

-- Step 3: Insert into dbo.KPIDBList (Skipping existing records)
INSERT INTO dbo.KPIDBList (
    DBName, SeqNo, DBType, DBConnStr, ProductID,
    CADIPAddr, CADPort, NCICIPAddr, NCICPort, RptConnStr,
    IsDBLink, IsMain, VehLogConnStr, ASConnStr, AgencyID,
    FriendlyName, RunMode, IsActive, InActiveDttm, CreatedBy,
    CreatedDttm, ModifiedBy, ModifiedDttm, ArchConnStr,
    JurisName, JurisAlias, TenantID, IsEncrypted
)
SELECT * FROM (
    VALUES
"@

$kpiValues = @()
$urlValues = @()

foreach ($db in $dbConfigs) {
    $cadPort = if ($db.RunMode -eq 1) { 8888 } else { 8887 }
    $ncicPort = if ($db.RunMode -eq 1) { 5858 } else { 5859 }

    $cadIpStr = if ($db.Product -in @("Police", "CAD")) { "@IPAddress" } else { "NULL" }
    $cadPortStr = if ($db.Product -in @("Police", "CAD")) { $cadPort } else { "NULL" }
    
    $ncicIpStr = if ($db.Product -in @("Police", "IA", "CAD")) { "@IPAddress" } else { "NULL" }
    $ncicPortStr = if ($db.Product -in @("Police", "IA", "CAD")) { $ncicPort } else { "NULL" }

    $kpiValues += "('$($db.DBName)', 1, 'MSSQL', @DBConnStr, $($db.ProductID), $cadIpStr, $cadPortStr, $ncicIpStr, $ncicPortStr, NULL, NULL, NULL, NULL, @DBConnStr, @AgencyID, '$($db.DBName)', $($db.RunMode), 1, NULL, @AgencyID, GETDATE(), @AgencyID, GETDATE(), NULL, NULL, NULL, NULL, 1)"

    if ($db.Product -ne "CAD") {
        for ($i = 0; $i -lt $urls.Count; $i++) {
            $varName = "@AccessURL$($i+1)"
            $urlValues += "(@AgencyID, '$($db.DBName)', $varName)"
        }
    }
}

$sql += "`n" + ($kpiValues -join ",`n")

$sql += @"

) AS src (
    DBName, SeqNo, DBType, DBConnStr, ProductID,
    CADIPAddr, CADPort, NCICIPAddr, NCICPort, RptConnStr,
    IsDBLink, IsMain, VehLogConnStr, ASConnStr, AgencyID,
    FriendlyName, RunMode, IsActive, InActiveDttm, CreatedBy,
    CreatedDttm, ModifiedBy, ModifiedDttm, ArchConnStr,
    JurisName, JurisAlias, TenantID, IsEncrypted
)
WHERE NOT EXISTS (
    SELECT 1 FROM dbo.KPIDBList tgt WHERE tgt.DBName = src.DBName
);

-- Step 4: Insert into KPIDBAccessURL (excluding CAD, skipping existing)
INSERT INTO dbo.KPIDBAccessURL (AgencyID, DBName, AccessURL)
SELECT * FROM (
    VALUES
"@

$sql += "`n" + ($urlValues -join ",`n")

$sql += @"

) AS src (AgencyID, DBName, AccessURL)
WHERE NOT EXISTS (
    SELECT 1 FROM dbo.KPIDBAccessURL tgt 
    WHERE tgt.AgencyID = src.AgencyID 
      AND tgt.DBName = src.DBName 
      AND tgt.AccessURL = src.AccessURL
);
"@

# ==========================================
# 7. Save to C:\PnxTemp\
# ==========================================
$outPath = "C:\PnxTemp"
if (-not (Test-Path -Path $outPath)) {
    New-Item -ItemType Directory -Path $outPath | Out-Null
    Write-Host "Created directory: $outPath" -ForegroundColor Green
}

$outFile = Join-Path $outPath "Generate_KPI_Script.sql"
$sql | Out-File -FilePath $outFile -Encoding UTF8

Write-Host "`n===============================================" -ForegroundColor Green
Write-Host "SUCCESS! Your SQL script has been saved to:" -ForegroundColor Green
Write-Host $outFile -ForegroundColor Cyan
Write-Host "===============================================" -ForegroundColor Green
Write-Host ""

# ==========================================
# 8. Execute SQL Script
# ==========================================
Write-Host "--- Step 8: Database Execution ---" -ForegroundColor Cyan
$runSql = Read-Host "Do you want to execute this script now against the PhoenixMaster database? (Y/N)"

if ($runSql -match "(?i)^Y$") {
    $sqlInstance = Read-Host "Enter SQL Instance Name (e.g., localhost, or localhost\SQLEXPRESS)"
    
    $authChoice = ""
    while ($authChoice -notmatch "(?i)^(Y|N)$") {
        $authChoice = Read-Host "Use Windows Authentication? (Y/N)"
    }

    $connString = "Server=$sqlInstance;Database=PhoenixMaster;"
    
    if ($authChoice -match "(?i)Y") {
        $connString += "Integrated Security=True;"
    } else {
        $sqlUser = Read-Host "Enter SQL Username (e.g., sa)"
        # Hide password input
        $sqlPass = Read-Host "Enter SQL Password" -AsSecureString
        # Convert SecureString back to plain text for the connection string
        $bstr = [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($sqlPass)
        $plainPass = [System.Runtime.InteropServices.Marshal]::PtrToStringAuto($bstr)
        $connString += "User ID=$sqlUser;Password=$plainPass;"
    }

    Write-Host "`nConnecting to '$sqlInstance' and executing script..." -ForegroundColor Yellow
    
    try {
        $connection = New-Object System.Data.SqlClient.SqlConnection
        $connection.ConnectionString = $connString
        $connection.Open()

        $command = $connection.CreateCommand()
        $command.CommandText = $sql
        $command.ExecuteNonQuery() | Out-Null

        Write-Host "`nSUCCESS: The script was executed successfully against PhoenixMaster!" -ForegroundColor Green
    } catch {
        Write-Host "`nERROR executing SQL script:" -ForegroundColor Red
        Write-Host $_.Exception.Message -ForegroundColor Red
    } finally {
        if ($connection.State -eq 'Open') {
            $connection.Close()
        }
        # Cleanup plain text password variable
        $plainPass = "" 
    }
} else {
    Write-Host "Execution skipped. You can manually run the generated file." -ForegroundColor Yellow
}

# Open the folder for easy viewing regardless of auto-execute choice
Invoke-Item $outPath

# --- Add these two lines here ---
Write-Host "`nScript execution is complete." -ForegroundColor Cyan

Read-Host -Prompt "Press Enter to close the terminal"
[Environment]::Exit(0)