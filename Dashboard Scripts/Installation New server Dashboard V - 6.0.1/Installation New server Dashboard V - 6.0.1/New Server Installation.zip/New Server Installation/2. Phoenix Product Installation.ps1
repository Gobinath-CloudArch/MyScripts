# ==============================================================================
# ProPhoenix Master Provisioning & Configuration Workflow
# Phase 1: Phoenix App Manager Installer
# Phase 2: IIS App Pool Creation
# Phase 3: Folders & Shares Configuration
# Phase 4: Automated Application Settings (JSON/XML)
# ==============================================================================
Clear-Host
$ErrorActionPreference = "Stop"

# --- Admin Check ---
if (-not ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    Write-Host "❌ ERROR: This script must be run as Administrator." -ForegroundColor Red
    Read-Host -Prompt "Press Enter to close the terminal"
    exit
}

# --- Setup Temp Directory ---
$tempDir = "C:\PnxTemp"
if (-not (Test-Path $tempDir)) { New-Item -ItemType Directory -Path $tempDir -Force | Out-Null }
$batchFilePath = Join-Path $tempDir "PhoenixProvisioning.bat"

Write-Host "======================================================" -ForegroundColor Cyan
Write-Host " PROPHOENIX MASTER SETUP - INPUT GATHERING PHASE" -ForegroundColor Cyan
Write-Host "======================================================" -ForegroundColor Cyan

# ==============================================================================
# 1. GATHER ALL INPUTS
# ==============================================================================

# --- License Verification ---
while ($true) {
    $LicenseAdded = Read-Host "Is the Install Type License key added? (Yes/No)"
    if ($LicenseAdded -match "^(Y|Yes|y|yes)$") { break } 
    else {
        Write-Host "Please update the Install type License first and come back again." -ForegroundColor Yellow
        Read-Host -Prompt "Press Enter to close the terminal"
        exit
    }
}

# --- Auto-Detect AppMgr Path ---
Write-Host "`nScanning for Server Application Manager..." -ForegroundColor Cyan
$AppMgrExePath = ""
foreach ($drive in (Get-PSDrive -PSProvider FileSystem).Name) {
    $testPath = "${drive}:\Program Files (x86)\ProPhoenix\Server Application Manager"
    if (Test-Path "$testPath\PnxAppMgr.exe") {
        $AppMgrExePath = $testPath
        break
    }
}
if (-not $AppMgrExePath) {
    Write-Host "❌ Could not find 'Server Application Manager' on any drive. Exiting." -ForegroundColor Red
    Read-Host -Prompt "Press Enter to close the terminal"
    exit
}
Write-Host "✅ Found Server Application Manager at: $AppMgrExePath" -ForegroundColor Green

# --- Installation Drive & Instance ---
$PnxDriveInput = Read-Host "`nEnter the drive letter for ProPhoenix installation [Default: C]"
if ([string]::IsNullOrWhiteSpace($PnxDriveInput)) { $PnxDriveInput = "C" }
$PnxDrive = ($PnxDriveInput -replace '[:\\\s]', '').Substring(0,1).ToUpper()
$PnxInstallPath = "$($PnxDrive):\Program Files\ProPhoenix"

$AllInOne = 0
while ($true) {
    Write-Host "`n--- Instance Name Selection ---"
    Write-Host "1. Live"
    Write-Host "2. Test"
    Write-Host "3. Demo"
    Write-Host "4. All in One Server for Live"
    $InstanceChoice = Read-Host "Select Instance Name (1-4)"

    if ($InstanceChoice -eq '1') { $SelectedInstance = "Live"; break }
    elseif ($InstanceChoice -eq '2') { $SelectedInstance = "Test"; break }
    elseif ($InstanceChoice -eq '3') { $SelectedInstance = "Demo"; break }
    elseif ($InstanceChoice -eq '4') { $SelectedInstance = "Live"; $AllInOne = 1; break }
}

$ServerChoice = "ALL"
if ($SelectedInstance -eq "Live" -and $AllInOne -eq 0) {
    while ($true) {
        Write-Host "`n--- Server Type Selection (Live Only) ---"
        Write-Host "1. RMS Server"
        Write-Host "2. CAD Server"
        Write-Host "3. Report Server"
        $ServerInput = Read-Host "On which server are you running? (1-3)"
        if ($ServerInput -match "^[1-3]$") { $ServerChoice = $ServerInput; break }
    }
}

# --- Database Credentials (Required for AppMgr Batch) ---
Write-Host "`n--- Database Configuration ---"
$DBServer = Read-Host "Enter DB Server [Default: localhost]"
if ([string]::IsNullOrWhiteSpace($DBServer)) { $DBServer = "localhost" }
$DBUserName = Read-Host "Enter DB SA User Name [Default: sa]"
if ([string]::IsNullOrWhiteSpace($DBUserName)) { $DBUserName = "sa" }
$DBPasswordSecure = Read-Host -AsSecureString "Enter DB Password"
$DBPassword = [System.Runtime.InteropServices.Marshal]::PtrToStringAuto([System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($DBPasswordSecure))

# --- Updater Settings ---
Write-Host "`n--- Updater Version ---"
Write-Host "1. 2024R2"
Write-Host "2. 2026"
$VersionChoice = Read-Host "Select Updater Version (1-2)"
$UpdateLocation = if ($VersionChoice -eq '1') { "2024R2" } else { "2026" }

Write-Host "`n--- Updater Account ---"
Write-Host "1. sftpupdates"
Write-Host "2. sftpinternals"
$AccountChoice = Read-Host "Select Updater Account (1-2)"
$UpdaterUserName = if ($AccountChoice -eq '1') { "sftpupdates" } else { "sftpinternals" }
$UpdaterPasswordSecure = Read-Host -AsSecureString "Enter password for $UpdaterUserName"
$UpdaterPassword = [System.Runtime.InteropServices.Marshal]::PtrToStringAuto([System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($UpdaterPasswordSecure))

# --- Auto-Config Data (SSRS & Cert) ---
Write-Host "`n--- Final Settings ---"
$ssrsUser = Read-Host "Enter SSRS Report Server Username"
$ssrsDomain = Read-Host "Enter SSRS Domain"
$certName = Read-Host "Enter Certificate Name (e.g., rms.yourcity.gov)"

# ==============================================================================
# 2. DISPLAY SUMMARY & CONFIRM EXECUTION
# ==============================================================================

Write-Host "`n======================================================" -ForegroundColor Cyan
Write-Host " SUMMARY OF CONFIGURATIONS" -ForegroundColor Cyan
Write-Host "======================================================" -ForegroundColor Cyan
Write-Host "Install Path : $PnxInstallPath"
Write-Host "Instance     : $SelectedInstance"
Write-Host "Server Type  : $(if($ServerChoice -eq '1') {'RMS'} elseif($ServerChoice -eq '2') {'CAD'} elseif($ServerChoice -eq '3') {'Report'} else {'ALL'})"
Write-Host "DB Server    : $DBServer"
Write-Host "DB User      : $DBUserName"
Write-Host "Updater Acc  : $UpdaterUserName (Version: $UpdateLocation)"
Write-Host "SSRS Config  : $ssrsDomain\$ssrsUser"
Write-Host "Certificate  : $certName"
Write-Host "Batch File   : $batchFilePath"
Write-Host "======================================================`n" -ForegroundColor Cyan

while ($true) {
    $runBatch = Read-Host "Do you want to proceed and execute the full installation script now? (Y/N)"
    
    if ($runBatch -match "^(Y|y|Yes|yes)$") {
        Write-Host "`nStarting Execution Pipeline..." -ForegroundColor Green
        break
    } elseif ($runBatch -match "^(N|n|No|no)$") {
        Write-Host "`nExecution aborted by user." -ForegroundColor Yellow
        Write-Host "The generated batch file (if needed later) would be saved at: $batchFilePath" -ForegroundColor Cyan
        Read-Host -Prompt "Press Enter to close the terminal"
        exit
    }
}
# ==============================================================================
# 3. PHASE 1: GENERATE & RUN PHOENIX BATCH SCRIPT
# ==============================================================================
Write-Host "`n======================================================" -ForegroundColor Cyan
Write-Host "[PHASE 1] Generating and Executing App Manager Batch" -ForegroundColor Cyan
Write-Host "======================================================" -ForegroundColor Cyan
Write-Host " -> Status: RUNNING (Please wait for the external command window to close)..." -ForegroundColor Yellow

$batchCode = @"
@echo off
setlocal

set "AppMgrExePath=$AppMgrExePath"
set "PnxInstallPath=$PnxInstallPath"
set "SelectedInstance=$SelectedInstance"
set "ServerChoice=$ServerChoice"
set "Authentication=SQL"
set "DBServer=$DBServer"
set "DBUserName=$DBUserName"
set "DBPassword=$DBPassword"
set "UpdateLocation=$UpdateLocation"
set "UpdaterUserName=$UpdaterUserName"
set "UpdaterPassword=$UpdaterPassword"

cd /d "%AppMgrExePath%"

if "%ServerChoice%"=="1" goto SetRMS
if "%ServerChoice%"=="2" goto SetCAD
if "%ServerChoice%"=="3" goto SetReport
goto SetAll

:SetRMS
set "InstallApps="PoliceRMS" "FireRMS" "TraCSServer" "PhoenixWebService" "DBUtility" "FireWebService" "ProvisionManager" "FolderWatcher" "InternalAffair" "NIBRS" "EmailWatcher" "ADRWebService" "DocsServer" "ScenePD" "PDFService" "HazMatGuide" "PoliceF1HelpDocs" "FireF1HelpDocs" "IAF1HelpDocs" "PNXDIAGRAM" "PNXDIAGRAMAPI" "PhoenixAIWatcherService""
set "UpdateInstances="TraCSServer" "EmailWatcher" "FolderWatcher" "DocsServer""
goto EndSetVars

:SetCAD
set "InstallApps="CADServer" "E911Server" "GPSServer" "ExternalInterface" "NCICServer" "NCICStateServer" "KGISPDServer" "DeviceNotification" "PnxWDAAppWebService" "StreamingNotification" "PhoenixTExt2Dispatch" "CAD2CADTellusServer" "ReportWriterAPI" "StageCADClient" "StageWDA" "StageClientAppManager" "StagePhoenixWDAV2""
set "UpdateInstances="CADServer" "CADNLBServer" "CAD2CADTellusServer" "E911Server" "ExternalInterface" "GPSServer" "NCICServer" "NCICStateServer" "DeviceNotification" "StreamingNotification" "PhoenixTExt2Dispatch""
goto EndSetVars

:SetReport
set "InstallApps="JobServer" "ReportServer" "PhoenixJobsvrv2""
set "UpdateInstances="JobServer""
goto EndSetVars

:SetAll
set "InstallApps="PoliceRMS" "FireRMS" "JobServer" "TraCSServer" "ReportServer" "PhoenixWebService" "DBUtility" "FireWebService" "ProvisionManager" "FolderWatcher" "InternalAffair" "NIBRS" "EmailWatcher" "CADServer" "E911Server" "GPSServer" "ExternalInterface" "NCICServer" "NCICStateServer" "KGISPDServer" "DeviceNotification" "PnxWDAAppWebService" "StreamingNotification" "PhoenixTExt2Dispatch" "CAD2CADTellusServer" "ReportWriterAPI" "FireCSPWebsite" "ADRWebService" "DocsServer" "PDFService" "StageCADClient" "StageWDA" "StageClientAppManager" "StagePhoenixWDAV2" "HazMatGuide" "PoliceF1HelpDocs" "FireF1HelpDocs" "IAF1HelpDocs" "PNXDIAGRAM" "PNXDIAGRAMAPI" "PhoenixJobsvrv2" "PhoenixAIWatcherService""
set "UpdateInstances="JobServer" "TraCSServer" "EmailWatcher" "CADServer" "CADNLBServer" "CAD2CADTellusServer" "E911Server" "ExternalInterface" "GPSServer" "NCICServer" "NCICStateServer" "DeviceNotification" "StreamingNotification" "FolderWatcher" "DocsServer" "PhoenixTExt2Dispatch""
goto EndSetVars

:EndSetVars

PnxAppMgr.exe "MASTERDB" "Authtype=%Authentication%" "server=%DBServer%" "username=%DBUserName%" "password=%DBPassword%"
PnxAppMgr.exe "UPDATERSETTINGS" "CheckEvery=24" "IsSFTP=Yes" "UpdateLocation=%UpdateLocation%" "IsDownReleaseCand=No" "UserName=%UpdaterUserName%" "Password=%UpdaterPassword%" "Domain=sftp.prophoenix.com" "SFTPPort=25544" "IsProxy=No" "ProxyAddress=" "IsByPassProxy=No" "IsUseDefaultCredentaials=Yes" "ProxyUserName=" "ProxyPassword=" "ProxyDomain=" "PreferredDownPath=C:\PhoenixAppDownloads" "LogLevel=None" "IsIgnoreMSIDownLog=No" "LicenceAPIurl=https://crmws.prophoenix.com/customermgmt"

PnxAppMgr.exe "MAINSETTINGS" "RMSRootPath" "PoliceRms=%PnxInstallPath%\Police RMS" "FireRms=%PnxInstallPath%\Fire RMS" "JobServer=%PnxInstallPath%\Job Server" "TraCSServer=%PnxInstallPath%\TraCS Server" "ReportServer=%PnxInstallPath%\Report Server" "PhoenixWebService=%PnxInstallPath%\WebService" "HazmatGuide=%PnxInstallPath%\User Docs" "FireWebService=%PnxInstallPath%\Fire WebService" "ProvisionManager=%PnxInstallPath%\Provision Manager" "FolderWatcher=%PnxInstallPath%\PnxFolderWatcher" "InternalAffair=%PnxInstallPath%\PhoenixIA" "NIBRS=%PnxInstallPath%\NIBRSInterface" "EmailWatcher=%PnxInstallPath%\Phoenix Email Watcher" "PoliceF1HelpDocs=%PnxInstallPath%\Police RMS\UserDocs" "FireF1HelpDocs=%PnxInstallPath%\Fire RMS\UserDocs" "IAF1HelpDocs=%PnxInstallPath%\PhoenixIA\UserDocs" "PNXDIAGRAM=%PnxInstallPath%\PNXDIAGRAM" "PNXDIAGRAMAPI=%PnxInstallPath%\PNXDIAGRAMAPI" "CAMERASERVER=%PnxInstallPath%\Phoenix Camera Server" "INSPECTIONAPI=%PnxInstallPath%\Phoenix Inspection API" "PhoenixAIWatcherService=%PnxInstallPath%\Phoenix AI Watcher" "PhoenixJobsvrv2=%PnxInstallPath%\Job Server V2"
PnxAppMgr.exe "MAINSETTINGS" "CADRootPath" "CADServer=%PnxInstallPath%\CAD Server" "CADNLBServer=%PnxInstallPath%\CAD NLB Message Server" "E911Server=%PnxInstallPath%\E911 Server" "GPSServer=%PnxInstallPath%\GPS Server" "ExternalInterface=%PnxInstallPath%\External Interface Server" "NCICServer=%PnxInstallPath%\NCIC Server" "NCICStateServer=%PnxInstallPath%\NCIC State Server" "KGISPDServer=%PnxInstallPath%\KGIS PD WebService" "KGISCentralServer=%PnxInstallPath%\KGIS Central WebService" "DeviceNotification=%PnxInstallPath%\Phoenix Device Notification" "PnxWDAAppWebService=%PnxInstallPath%\WDA App webservice" "StreamingNotification=%PnxInstallPath%\Streaming Notification" "PhoenixTExt2Dispatch=%PnxInstallPath%\Text2Dispatch" "CAD2CADTellusServer=%PnxInstallPath%\CAD2CAD Tellus Server" "ReportWriterAPI=%PnxInstallPath%\Phoenix Report Writer API"
PnxAppMgr.exe "MAINSETTINGS" "OtherRootPath" "CitizenServices=%PnxInstallPath%\Citizen Services Link" "InmateLookup=%PnxInstallPath%\Inmate Lookup" "WIJIS=%PnxInstallPath%\WIJIS" "SWISS=%PnxInstallPath%\SWISS" "CJIN=%PnxInstallPath%\CJIN Integration Service" "NDEX=%PnxInstallPath%\WIJIS NDEX WebService" "CRM=%PnxInstallPath%\CRM" "InmateLocator=%PnxInstallPath%\Inmate Locator" "FireCSPWCF=%PnxInstallPath%\FireCSPhoenixLink" "PoliceCSPWebAPI=%PnxInstallPath%\CitizenServices" "FireCSPWebsite=%PnxInstallPath%\FireCitizenServices" "ADRWebService=%PnxInstallPath%\ADRCollectionRepositoryWS" "WhatsNewWebService=%PnxInstallPath%\WhatsNewWebService" "DocsServer=%PnxInstallPath%\DocsServer" "JailCellCheck=%PnxInstallPath%\Jail Cell Check App Service" "ScenePD=%PnxInstallPath%\PhoenixScenePD" "PDFService=%PnxInstallPath%\PhoenixPDFService" "DBUtility=%PnxInstallPath%\Database Utility" "PHOENIXPAWN=%PnxInstallPath%\Phoenix Pawn" "FIRECSPCONVERSION=%PnxInstallPath%\Fire CSP Conversion"
PnxAppMgr.exe "MAINSETTINGS" "StageForClientAppsRootPath" "StageCADClient=%PnxInstallPath%\FTP\CAD Client Stage" "StageWDA=%PnxInstallPath%\FTP\WDA Stage" "StagePrintClient=%PnxInstallPath%\FTP\Print Server Stage" "StageClientAppManager=%PnxInstallPath%\FTP\Client Application Manager Stage" "StageFingerPrintClient=%PnxInstallPath%\FTP\Finger Print Client Stage" "StageIDScannerClient=%PnxInstallPath%\FTP\ID Scanner Stage" "StageStationKIOSKRFIDClient=%PnxInstallPath%\FTP\Station KIOSK RFID Client Stage" "StageRFIDClient=%PnxInstallPath%\FTP\RFID Client Stage" "StageAVLRecorder=%PnxInstallPath%\FTP\AVL Recorder Stage" "StageInOutClient=%PnxInstallPath%\FTP\In Out Client Stage" "StageZetronClient=%PnxInstallPath%\FTP\Zetron Client Stage" "StagePhoenixDashboard=%PnxInstallPath%\FTP\Phoenix Dashboard Stage" "StageMobileInspectionApp=%PnxInstallPath%\FTP\Mobile Inspection App Stage" "StagePhoenixWDAV2=%PnxInstallPath%\FTP\Phoenix WDA V2 Stage"
PnxAppMgr.exe "MAINSETTINGS" "InstallUtilPath" "Path=C:\WINDOWS\Microsoft.NET\Framework\v4.0.30319"

PnxAppMgr.exe "UPDAPPMANAGER" 

@echo off
timeout 10 > NUL

:loopSelf
tasklist /fi "imagename eq PnxAppMgr.exe" |find ":" > nul
if "%ERRORLEVEL%"=="1" goto loopSelf

cd /d "%AppMgrExePath%"

PnxAppMgr.exe "INSTALL" %InstallApps%

if "%ServerChoice%"=="1" goto CreateRMSVDirs
if "%ServerChoice%"=="2" goto CreateCADVDirs
if "%ServerChoice%"=="3" goto CreateReportVDirs
goto CreateAllVDirs

:CreateRMSVDirs
PnxAppMgr.exe "CREATEVIRTUALDIRINSTANCE" "Product=PoliceRMS" "VirtualDirName=Law" "ParentWebsite=" "PnxCustHlpPath=" "PnxBulkUpldPath=" "PnxVideosPath="
PnxAppMgr.exe "CREATEVIRTUALDIRINSTANCE" "Product=FireRMS" "VirtualDirName=Fire" "ParentWebsite=" "PnxCustHlpPath=" "PnxBulkUpldPath=" "PnxVideosPath="
PnxAppMgr.exe "CREATEVIRTUALDIRINSTANCE" "Product=InternalAffair" "VirtualDirName=IA" "ParentWebsite="
PnxAppMgr.exe "CREATEVIRTUALDIRINSTANCE" "Product=ScenePD" "VirtualDirName=ScenePDWebSDK" "ParentWebsite="
PnxAppMgr.exe "CREATEVIRTUALDIRINSTANCE" "Product=PhoenixWebService" "VirtualDirName=WebService" "ParentWebsite="
PnxAppMgr.exe "CREATEVIRTUALDIRINSTANCE" "Product=HazMatGuide" "VirtualDirName=UserDocs" "ParentWebsite="
PnxAppMgr.exe "CREATEVIRTUALDIRINSTANCE" "Product=FireWebService" "VirtualDirName=FireWS" "ParentWebsite="
PnxAppMgr.exe "CREATEVIRTUALDIRINSTANCE" "Product=ProvisionManager" "VirtualDirName=ProvisionManager" "ParentWebsite="
PnxAppMgr.exe "CREATEVIRTUALDIRINSTANCE" "Product=ADRWebService" "VirtualDirName=ADRRepository" "ParentWebsite="
PnxAppMgr.exe "CREATEVIRTUALDIRINSTANCE" "Product=NIBRS" "VirtualDirName=NIBRSService" "ParentWebsite="
PnxAppMgr.exe "CREATEVIRTUALDIRINSTANCE" "Product=PDFService" "VirtualDirName=PhoenixPDFService" "ParentWebsite="
PnxAppMgr.exe "CREATEVIRTUALDIRINSTANCE" "Product=PNXDIAGRAM" "VirtualDirName=PNXDiagram" "ParentWebsite="
PnxAppMgr.exe "CREATEVIRTUALDIRINSTANCE" "Product=PNXDIAGRAMAPI" "VirtualDirName=PNXDiagramAPI" "ParentWebsite="
goto EndVDirs

:CreateCADVDirs
PnxAppMgr.exe "CREATEVIRTUALDIRINSTANCE" "Product=KGISPDServer" "VirtualDirName=KGIS" "ParentWebsite="
PnxAppMgr.exe "CREATEVIRTUALDIRINSTANCE" "Product=PnxWDAAppWebService" "VirtualDirName=WDAApp" "ParentWebsite="
PnxAppMgr.exe "CREATEVIRTUALDIRINSTANCE" "Product=ReportWriterAPI" "VirtualDirName=WDAV2API" "ParentWebsite="
goto EndVDirs

:CreateReportVDirs
PnxAppMgr.exe "CREATEVIRTUALDIRINSTANCE" "Product=ReportServer" "VirtualDirName=PnxRptSvr" "ParentWebsite="
goto EndVDirs

:CreateAllVDirs
PnxAppMgr.exe "CREATEVIRTUALDIRINSTANCE" "Product=PoliceRMS" "VirtualDirName=Law" "ParentWebsite=" "PnxCustHlpPath=" "PnxBulkUpldPath=" "PnxVideosPath="
PnxAppMgr.exe "CREATEVIRTUALDIRINSTANCE" "Product=FireRMS" "VirtualDirName=Fire" "ParentWebsite=" "PnxCustHlpPath=" "PnxBulkUpldPath=" "PnxVideosPath="
PnxAppMgr.exe "CREATEVIRTUALDIRINSTANCE" "Product=InternalAffair" "VirtualDirName=IA" "ParentWebsite="
PnxAppMgr.exe "CREATEVIRTUALDIRINSTANCE" "Product=ReportServer" "VirtualDirName=PnxRptSvr" "ParentWebsite="
PnxAppMgr.exe "CREATEVIRTUALDIRINSTANCE" "Product=ScenePD" "VirtualDirName=ScenePDWebSDK" "ParentWebsite="
PnxAppMgr.exe "CREATEVIRTUALDIRINSTANCE" "Product=PhoenixWebService" "VirtualDirName=WebService" "ParentWebsite="
PnxAppMgr.exe "CREATEVIRTUALDIRINSTANCE" "Product=KGISPDServer" "VirtualDirName=KGIS" "ParentWebsite="
PnxAppMgr.exe "CREATEVIRTUALDIRINSTANCE" "Product=HazMatGuide" "VirtualDirName=UserDocs" "ParentWebsite="
PnxAppMgr.exe "CREATEVIRTUALDIRINSTANCE" "Product=FireWebService" "VirtualDirName=FireWS" "ParentWebsite="
PnxAppMgr.exe "CREATEVIRTUALDIRINSTANCE" "Product=PnxWDAAppWebService" "VirtualDirName=WDAApp" "ParentWebsite="
PnxAppMgr.exe "CREATEVIRTUALDIRINSTANCE" "Product=ReportWriterAPI" "VirtualDirName=WDAV2API" "ParentWebsite="
PnxAppMgr.exe "CREATEVIRTUALDIRINSTANCE" "Product=ProvisionManager" "VirtualDirName=ProvisionManager" "ParentWebsite="
PnxAppMgr.exe "CREATEVIRTUALDIRINSTANCE" "Product=CRM" "VirtualDirName=CRM" "ParentWebsite="
PnxAppMgr.exe "CREATEVIRTUALDIRINSTANCE" "Product=InmateLocator" "VirtualDirName=InmateLocator" "ParentWebsite="
PnxAppMgr.exe "CREATEVIRTUALDIRINSTANCE" "Product=FireCSPWCF" "VirtualDirName=FireCSPhoenixLink" "ParentWebsite="
PnxAppMgr.exe "CREATEVIRTUALDIRINSTANCE" "Product=PoliceCSPWebAPI" "VirtualDirName=CSPWebAPI" "ParentWebsite="
PnxAppMgr.exe "CREATEVIRTUALDIRINSTANCE" "Product=FireCSPWebsite" "VirtualDirName=FireCSP" "ParentWebsite="
PnxAppMgr.exe "CREATEVIRTUALDIRINSTANCE" "Product=ADRWebService" "VirtualDirName=ADRRepository" "ParentWebsite="
PnxAppMgr.exe "CREATEVIRTUALDIRINSTANCE" "Product=JailCellCheck" "VirtualDirName=JailCellCheck" "ParentWebsite="
PnxAppMgr.exe "CREATEVIRTUALDIRINSTANCE" "Product=NIBRS" "VirtualDirName=NIBRSService" "ParentWebsite="
PnxAppMgr.exe "CREATEVIRTUALDIRINSTANCE" "Product=CJIN" "VirtualDirName=CJINIntegrationService" "ParentWebsite="
PnxAppMgr.exe "CREATEVIRTUALDIRINSTANCE" "Product=PDFService" "VirtualDirName=PhoenixPDFService" "ParentWebsite="
PnxAppMgr.exe "CREATEVIRTUALDIRINSTANCE" "Product=PNXDIAGRAM" "VirtualDirName=PNXDiagram" "ParentWebsite="
PnxAppMgr.exe "CREATEVIRTUALDIRINSTANCE" "Product=PNXDIAGRAMAPI" "VirtualDirName=PNXDiagramAPI" "ParentWebsite="
PnxAppMgr.exe "CREATEVIRTUALDIRINSTANCE" "Product=CAMERASERVER" "VirtualDirName=PhoenixCameraServer" "ParentWebsite="
PnxAppMgr.exe "CREATEVIRTUALDIRINSTANCE" "Product=PHOENIXPAWN" "VirtualDirName=PhoenixPawn" "ParentWebsite="
PnxAppMgr.exe "CREATEVIRTUALDIRINSTANCE" "Product=INSPECTIONAPI" "VirtualDirName=PnxInspectionAPI" "ParentWebsite="
PnxAppMgr.exe "CREATEVIRTUALDIRINSTANCE" "Product=FIRECSPCONVERSION" "VirtualDirName=FireCSPConversion" "ParentWebsite="
goto EndVDirs

:EndVDirs

if "%ServerChoice%"=="1" goto CreateRMSServices
if "%ServerChoice%"=="2" goto CreateCADServices
if "%ServerChoice%"=="3" goto CreateReportServices
goto CreateAllServices

:CreateRMSServices
PnxAppMgr.exe "CREATEWINSERVICEINSTANCE" "Product=TraCSServer" "InstanceName=%SelectedInstance%"
PnxAppMgr.exe "CREATEWINSERVICEINSTANCE" "Product=EmailWatcher" "InstanceName=%SelectedInstance%"
PnxAppMgr.exe "CREATEWINSERVICEINSTANCE" "Product=WIJIS" "InstanceName=WIJISWeb" "ParentWebsite="
PnxAppMgr.exe "CREATEWINSERVICEINSTANCE" "Product=NDEX" "InstanceName=NDEXWeb" "ParentWebsite="
PnxAppMgr.exe "CREATEWINSERVICEINSTANCE" "Product=FolderWatcher" "InstanceName=%SelectedInstance%"
PnxAppMgr.exe "CREATEWINSERVICEINSTANCE" "Product=DocsServer" "InstanceName=%SelectedInstance%"
PnxAppMgr.exe "CREATEWINSERVICEINSTANCE" "Product=PhoenixAIWatcherService" "InstanceName=%SelectedInstance%"
if "%SelectedInstance%"=="Live" (
    PnxAppMgr.exe "CREATEWINSERVICEINSTANCE" "Product=FolderWatcher" "InstanceName=Training"
    PnxAppMgr.exe "CREATEWINSERVICEINSTANCE" "Product=EmailWatcher" "InstanceName=Training"
)
goto EndCreateServices

:CreateCADServices
PnxAppMgr.exe "CREATEWINSERVICEINSTANCE" "Product=CADServer" "InstanceName=%SelectedInstance%"
PnxAppMgr.exe "CREATEWINSERVICEINSTANCE" "Product=CADNLBServer" "InstanceName=%SelectedInstance%"
PnxAppMgr.exe "CREATEWINSERVICEINSTANCE" "Product=CAD2CADTellusServer" "InstanceName=%SelectedInstance%"
PnxAppMgr.exe "CREATEWINSERVICEINSTANCE" "Product=E911Server" "InstanceName=%SelectedInstance%"
PnxAppMgr.exe "CREATEWINSERVICEINSTANCE" "Product=ExternalInterface" "InstanceName=%SelectedInstance%"
PnxAppMgr.exe "CREATEWINSERVICEINSTANCE" "Product=GPSServer" "InstanceName=%SelectedInstance%"
PnxAppMgr.exe "CREATEWINSERVICEINSTANCE" "Product=NCICServer" "InstanceName=%SelectedInstance%"
PnxAppMgr.exe "CREATEWINSERVICEINSTANCE" "Product=NCICStateServer" "InstanceName=%SelectedInstance%"
PnxAppMgr.exe "CREATEWINSERVICEINSTANCE" "Product=DeviceNotification" "InstanceName=%SelectedInstance%"
PnxAppMgr.exe "CREATEWINSERVICEINSTANCE" "Product=StreamingNotification" "InstanceName=%SelectedInstance%"
PnxAppMgr.exe "CREATEWINSERVICEINSTANCE" "Product=PhoenixText2Dispatch" "InstanceName=%SelectedInstance%"
if "%SelectedInstance%"=="Live" (
    PnxAppMgr.exe "CREATEWINSERVICEINSTANCE" "Product=CADServer" "InstanceName=Training"
    PnxAppMgr.exe "CREATEWINSERVICEINSTANCE" "Product=NCICServer" "InstanceName=Training"
)
goto EndCreateServices

:CreateReportServices
PnxAppMgr.exe "CREATEWINSERVICEINSTANCE" "Product=JobServer" "InstanceName=%SelectedInstance%"
PnxAppMgr.exe "CREATEWINSERVICEINSTANCE" "Product=PhoenixJobsvrv2" "InstanceName=%SelectedInstance%"
if "%SelectedInstance%"=="Live" (
    PnxAppMgr.exe "CREATEWINSERVICEINSTANCE" "Product=JobServer" "InstanceName=Training"
    PnxAppMgr.exe "CREATEWINSERVICEINSTANCE" "Product=PhoenixJobsvrv2" "InstanceName=Training"
)
goto EndCreateServices

:CreateAllServices
PnxAppMgr.exe "CREATEWINSERVICEINSTANCE" "Product=JobServer" "InstanceName=%SelectedInstance%"
PnxAppMgr.exe "CREATEWINSERVICEINSTANCE" "Product=TraCSServer" "InstanceName=%SelectedInstance%"
PnxAppMgr.exe "CREATEWINSERVICEINSTANCE" "Product=EmailWatcher" "InstanceName=%SelectedInstance%"
PnxAppMgr.exe "CREATEWINSERVICEINSTANCE" "Product=CADServer" "InstanceName=%SelectedInstance%"
PnxAppMgr.exe "CREATEWINSERVICEINSTANCE" "Product=CADNLBServer" "InstanceName=%SelectedInstance%"
PnxAppMgr.exe "CREATEWINSERVICEINSTANCE" "Product=CAD2CADTellusServer" "InstanceName=%SelectedInstance%"
PnxAppMgr.exe "CREATEWINSERVICEINSTANCE" "Product=E911Server" "InstanceName=%SelectedInstance%"
PnxAppMgr.exe "CREATEWINSERVICEINSTANCE" "Product=ExternalInterface" "InstanceName=%SelectedInstance%"
PnxAppMgr.exe "CREATEWINSERVICEINSTANCE" "Product=GPSServer" "InstanceName=%SelectedInstance%"
PnxAppMgr.exe "CREATEWINSERVICEINSTANCE" "Product=NCICServer" "InstanceName=%SelectedInstance%"
PnxAppMgr.exe "CREATEWINSERVICEINSTANCE" "Product=NCICStateServer" "InstanceName=%SelectedInstance%"
PnxAppMgr.exe "CREATEWINSERVICEINSTANCE" "Product=WIJIS" "InstanceName=WIJISWeb" "ParentWebsite="
PnxAppMgr.exe "CREATEWINSERVICEINSTANCE" "Product=NDEX" "InstanceName=NDEXWeb" "ParentWebsite="
PnxAppMgr.exe "CREATEWINSERVICEINSTANCE" "Product=DeviceNotification" "InstanceName=%SelectedInstance%"
PnxAppMgr.exe "CREATEWINSERVICEINSTANCE" "Product=StreamingNotification" "InstanceName=%SelectedInstance%"
PnxAppMgr.exe "CREATEWINSERVICEINSTANCE" "Product=FolderWatcher" "InstanceName=%SelectedInstance%"
PnxAppMgr.exe "CREATEWINSERVICEINSTANCE" "Product=DocsServer" "InstanceName=%SelectedInstance%"
PnxAppMgr.exe "CREATEWINSERVICEINSTANCE" "Product=PhoenixText2Dispatch" "InstanceName=%SelectedInstance%"
PnxAppMgr.exe "CREATEWINSERVICEINSTANCE" "Product=PhoenixJobsvrv2" "InstanceName=%SelectedInstance%"
PnxAppMgr.exe "CREATEWINSERVICEINSTANCE" "Product=PhoenixAIWatcherService" "InstanceName=%SelectedInstance%"
if "%SelectedInstance%"=="Live" (
    PnxAppMgr.exe "CREATEWINSERVICEINSTANCE" "Product=CADServer" "InstanceName=Training"
    PnxAppMgr.exe "CREATEWINSERVICEINSTANCE" "Product=FolderWatcher" "InstanceName=Training"
    PnxAppMgr.exe "CREATEWINSERVICEINSTANCE" "Product=JobServer" "InstanceName=Training"
    PnxAppMgr.exe "CREATEWINSERVICEINSTANCE" "Product=NCICServer" "InstanceName=Training"
    PnxAppMgr.exe "CREATEWINSERVICEINSTANCE" "Product=PhoenixJobsvrv2" "InstanceName=Training"
    PnxAppMgr.exe "CREATEWINSERVICEINSTANCE" "Product=EmailWatcher" "InstanceName=Training"
)
goto EndCreateServices

:EndCreateServices

PnxAppMgr.exe "UPDATEINSTANCE" %UpdateInstances%
PnxAppMgr.exe "SHOWINSTANCES"
PnxAppMgr.exe "SHOWSETTINGS" "PoliceRMS" "FireRMS" "JobServer" "TraCSServer" "ReportServer" "PhoenixWebService" "HazMatGuide" "DBUtility" "FireWebService" "ProvisionManager" "FolderWatcher" "InternalAffair" "EmailWatcher" "CADServer" "CADNLBServer" "E911Server" "GPSServer" "ExternalInterface" "NCICServer" "NCICStateServer" "KGISPDServer" "DeviceNotification" "PnxWDAAppWebService" "StreamingNotification" "PhoenixTExt2Dispatch" "CAD2CADTellusServer" "ReportWriterAPI" "WIJIS" "NDEX" "CRM" "InmateLocator" "FireCSPWCF" "PoliceCSPWebAPI" "FireCSPWebsite" "ADRWebService" "DocsServer" "JailCellCheck" "ScenePD" "PoliceF1HelpDocs" "FireF1HelpDocs" "IAF1HelpDocs" "StageCADClient" "StageWDA" "StagePrintClient" "StageClientAppManager" "StageFingerPrintClient" "StageIDScannerClient" "StageStationKIOSKRFIDClient" "StageRFIDClient" "StageAVLRecorder" "StageInOutClient" "StageZetronClient" "StagePhoenixDashboard" "StageMobileInspectionApp" "StagePhoenixWDAV2"

pause
exit
"@
Set-Content -Path $batchFilePath -Value $batchCode -Encoding ASCII

# Use -PassThru to monitor the process for unexpected exits
$batchProcess = Start-Process -FilePath "cmd.exe" -ArgumentList "/c `"$batchFilePath`"" -Wait -WindowStyle Normal -Verb RunAs -PassThru

# Exit Code 0 generally means successful completion to the 'exit' command.
if ($batchProcess.ExitCode -ne 0) {
    Write-Host "`n⚠️ It seems like the batch script was closed manually or not executed properly." -ForegroundColor Yellow
    $continueChoice = Read-Host "Would you like to continue or stop executing the script here after? (Continue/Stop)"
    
    if ($continueChoice -match "^(Stop|S|No|N)$") {
        Write-Host "Execution stopped by user." -ForegroundColor Red
        Read-Host -Prompt "Press Enter to close the terminal"
        exit
    }
}
Write-Host " -> Status: COMPLETED" -ForegroundColor Green

# ==============================================================================
# 4. PHASE 2: IIS APP POOL CONFIGURATION
# ==============================================================================
Write-Host "`n======================================================" -ForegroundColor Cyan
Write-Host "[PHASE 2] Configuring IIS App Pools" -ForegroundColor Cyan
Write-Host "======================================================" -ForegroundColor Cyan
Write-Host " -> Status: RUNNING..." -ForegroundColor Yellow

$rmsApps = @("Law", "Fire", "IA", "ADR", "NIBRSService", "KGIS", "ProvisionManager", "Webservice", "FireWS", "PhoenixPDFService", "PnxDiagram", "PnxDiagramAPI", "UserDocs", "PhoenixInspectionAPI")
$cadApps = @("WDAApp", "WDAV2API")

$masterApplications = @{
    "Law"                  = "PhoenixPolice";  "Fire"                 = "PhoenixFire";
    "IA"                   = "PhoenixIA";      "ADR"                  = "ADR";
    "NIBRSService"         = "NIBRS";          "PnxRptSvr"            = "PnxRptSvr";
    "KGIS"                 = "KGISPD";         "ProvisionManager"     = "ProvisionManager";
    "Webservice"           = "Webservice";     "FireWS"               = "FireWS";
    "WDAApp"               = "WDAApp";         "PhoenixPDFService"    = "PhoenixPDFService";
    "PnxDiagram"           = "PnxDiagram";     "PnxDiagramAPI"        = "PnxDiagramAPI";
    "UserDocs"             = "UserDocs";       "WDAV2API"             = "WDAV2API"
    "PhoenixInspectionAPI" = "PhoenixInspectionAPI"
}

$applications = @{}
if ($ServerChoice -eq '1') { foreach ($app in $rmsApps) { if ($masterApplications.ContainsKey($app)) { $applications[$app] = $masterApplications[$app] } } } 
elseif ($ServerChoice -eq '2') { foreach ($app in $cadApps) { if ($masterApplications.ContainsKey($app)) { $applications[$app] = $masterApplications[$app] } } } 
else { $applications = $masterApplications }

$targetAppPools = $applications.Values | Select-Object -Unique
$appCmdPath = "$env:windir\system32\inetsrv\appcmd.exe"
Import-Module WebAdministration -ErrorAction SilentlyContinue

foreach ($pool in $targetAppPools) {
    Write-Host "  -> Processing App Pool: $pool" -ForegroundColor Gray
    $exists = & $appCmdPath list apppool /name:"$pool" /text:name 2>$null
    if ([string]::IsNullOrEmpty($exists)) {
        & $appCmdPath add apppool /name:"$pool" | Out-Null
        & $appCmdPath set apppool /apppool.name:"$pool" /"processModel.identityType":"NetworkService" | Out-Null
        & $appCmdPath set apppool /apppool.name:"$pool" /"enable32BitAppOnWin64":"false" | Out-Null
        
        $runtime = if (@("WDAV2API", "PnxDiagram", "PnxDiagramAPI", "PhoenixInspectionAPI") -contains $pool) { "" } else { "v4.0" }
        & $appCmdPath set apppool /apppool.name:"$pool" /"managedRuntimeVersion":"$runtime" | Out-Null

        if (@("PhoenixPolice", "PhoenixFire", "PhoenixIA") -contains $pool) { & $appCmdPath set apppool /apppool.name:"$pool" /"processModel.idleTimeoutAction":"Suspend" | Out-Null }
        if ($pool -eq "PhoenixPolice") { & $appCmdPath set apppool /apppool.name:"$pool" /"failure.rapidFailProtection":"false" | Out-Null }
    } else {
        Write-Host "     (Pool already exists. Skipping creation.)" -ForegroundColor DarkGray
    }
}

foreach ($app in $applications.Keys) {
    $pool = $applications[$app]
    try { 
        & $appCmdPath set app /app.name:"Default Web Site/$app" /applicationPool:"$pool" | Out-Null 
        Write-Host "  -> Mapped $app to $pool" -ForegroundColor DarkGray
    } catch {}
}

if ($targetAppPools -contains "PhoenixPDFService") {
    Write-Host "  -> Applying stability fix to PhoenixPDFService..." -ForegroundColor Gray
    try {
        Set-ItemProperty "IIS:\AppPools\PhoenixPDFService" -Name "processModel.idleTimeout" -Value "00:20:00" -ErrorAction SilentlyContinue
        Set-ItemProperty "IIS:\AppPools\PhoenixPDFService" -Name "recycling.periodicRestart.time" -Value "1.00:00:00" -ErrorAction SilentlyContinue
    } catch {}
}

Get-Service -Name "Phoenix*", "aspnet_state" -ErrorAction SilentlyContinue | ForEach-Object {
    Invoke-Expression "sc.exe failure `"$($_.Name)`" reset= 86400 actions= restart/60000/restart/60000/restart/60000" | Out-Null
}

Write-Host " -> Status: COMPLETED" -ForegroundColor Green

# ==============================================================================
# 5. PHASE 3: FOLDERS AND SHARES CONFIGURATION
# ==============================================================================
Write-Host "`n======================================================" -ForegroundColor Cyan
Write-Host "[PHASE 3] Applying Folders and Shares" -ForegroundColor Cyan
Write-Host "======================================================" -ForegroundColor Cyan
Write-Host " -> Status: RUNNING..." -ForegroundColor Yellow

$hostName = $env:COMPUTERNAME
$basePath = "$PnxInstallPath"
$folderSummary = @()
$shareSummary = @()

try {
    Set-Service -Name "aspnet_state" -StartupType Automatic -ErrorAction Stop
    Start-Service -Name "aspnet_state" -ErrorAction Stop
} catch {}

if (!(Test-Path $basePath)) { New-Item -ItemType Directory -Path $basePath -Force | Out-Null }
try {
    $acl = Get-Acl -Path $basePath
    $targetIdentities = @([System.Security.Principal.WindowsIdentity]::GetCurrent().Name, (New-Object System.Security.Principal.SecurityIdentifier("S-1-5-32-544")).Translate([System.Security.Principal.NTAccount]).Value, (New-Object System.Security.Principal.SecurityIdentifier("S-1-5-32-545")).Translate([System.Security.Principal.NTAccount]).Value, "NT AUTHORITY\NETWORK SERVICE", "NT AUTHORITY\IUSR") | Select-Object -Unique
    foreach ($identity in $targetIdentities) {
        $acl.AddAccessRule((New-Object System.Security.AccessControl.FileSystemAccessRule($identity, "FullControl", "ContainerInherit,ObjectInherit", "None", "Allow")))
    }
    Set-Acl -Path $basePath -AclObject $acl
} catch {}

$foldersToCreate = @("Custom", "Attachment", "Attachment\Job", "Watch", "WatchTr", "ScreenDocs", "Attachment\BulkUpload")
if (Test-Path (Join-Path $basePath "Police RMS\Records")) { $foldersToCreate += "Police RMS\Records\Hotsheet" }
if (Test-Path (Join-Path $basePath "FTP")) { $foldersToCreate += "FTP\CAD Data\KPIDATA"; $foldersToCreate += "FTP\WDA Data\KPIDATA" }

$cadInstances = @(); if (Test-Path (Join-Path $basePath "CAD Server\_Instances")) { $cadInstances = (Get-ChildItem -Path (Join-Path $basePath "CAD Server\_Instances") -Directory).Name }
$pnxInstances = @(); if (Test-Path (Join-Path $basePath "PnxFolderWatcher\_Instance")) { $pnxInstances = (Get-ChildItem -Path (Join-Path $basePath "PnxFolderWatcher\_Instance") -Directory).Name }

foreach ($cadInst in $cadInstances) { $foldersToCreate += "CAD Server\_Instances\$cadInst\Bolo" }
foreach ($pnxInst in $pnxInstances) {
    $foldersToCreate += "PnxFolderWatcher\_Instance\$pnxInst\Rpt"
    $foldersToCreate += "PnxFolderWatcher\_Instance\$pnxInst\Rpt\GettxtFile"
    $foldersToCreate += "PnxFolderWatcher\_Instance\$pnxInst\Rpt\ProcessedRpt"
    $foldersToCreate += "PnxFolderWatcher\_Instance\$pnxInst\Rpt\ErrorRpt"
}

foreach ($folder in $foldersToCreate) {
    $fullPath = Join-Path $basePath $folder
    if (-not (Test-Path $fullPath)) { 
        New-Item -ItemType Directory -Path $fullPath -Force | Out-Null
        $folderSummary += [PSCustomObject]@{ Status = "Created"; Path = $fullPath } 
    } else {
        $folderSummary += [PSCustomObject]@{ Status = "Existing"; Path = $fullPath }
    }
}

$sharesToManage = @{ "Custom"="Custom"; "Job"="Attachment\Job"; "Hotsheet"="Police RMS\Records\Hotsheet"; "ScreenDocs"="ScreenDocs"; "Attachment"="Attachment"; "BulkUpload"="Attachment\BulkUpload"; "ftp"="FTP"; "Watch"="Watch"; "WDA App webservice"="WDA App webservice"; "Phoenix Report Writer API"="Phoenix Report Writer API"; "Fire WebService"="Fire WebService"; "Fire Response CAD Webservice"="Fire Response CAD Webservice" }
foreach ($cadInst in $cadInstances) {
    $boloRelPath = "CAD Server\_Instances\$cadInst\Bolo"
    if ($cadInst -match "Live") { $sharesToManage["Bolo"] = $boloRelPath } elseif ($cadInst -match "Training") { $sharesToManage["Bolo2"] = $boloRelPath } else { $sharesToManage["Bolo_$cadInst"] = $boloRelPath }
}

foreach ($shareName in $sharesToManage.Keys) {
    $targetFolderPath = Join-Path $basePath $sharesToManage[$shareName]
    $uncPath = "\\$hostName\$shareName"
    if (Test-Path $targetFolderPath) {
        if (-not (Get-SmbShare -Name $shareName -ErrorAction SilentlyContinue)) { 
            New-SmbShare -Name $shareName -Path $targetFolderPath -FullAccess "Everyone" | Out-Null 
            $shareSummary += [PSCustomObject]@{ Status = "Created"; ShareName = $shareName; UNC = $uncPath }
        } else {
            $shareSummary += [PSCustomObject]@{ Status = "Existing"; ShareName = $shareName; UNC = $uncPath }
        }
    }
}

Write-Host "`n--- Folder Status ---" -ForegroundColor Yellow
$folderSummary | Format-Table -AutoSize | Out-String | Write-Host
Write-Host "--- Share Status ---" -ForegroundColor Yellow
$shareSummary | Format-Table -AutoSize | Out-String | Write-Host

Write-Host " -> Status: COMPLETED" -ForegroundColor Green


# ==============================================================================
# 6. PHASE 4: AUTOMATED CONFIGURATION (JSON/XML)
# ==============================================================================
Write-Host "`n======================================================" -ForegroundColor Cyan
Write-Host "[PHASE 4] Applying Automated Application Configurations" -ForegroundColor Cyan
Write-Host "======================================================" -ForegroundColor Cyan
Write-Host " -> Status: RUNNING..." -ForegroundColor Yellow

$jsonConfig = @"
[
  {
    "AppName": "CAD Server",
    "RelativePath": "CAD Server\\_Instances\\*\\KPI.Phoenix.CADServerSvc.exe.config",
    "Settings": { "KPIRMSURL": "http://{cert_name}/Police", "KPIFireRMSURL": "http://{cert_name}/Fire", "DeviceNotifySvrIP": "{hostname}", "DeviceNotificationSvrPort": "5555", "IsSignalRNotifySvc": "TRUE", "SignalRSvcURL": "https://{hostname}:8245", "RptServer_UserName": "{ssrs_user}", "RptServer_Domain": "{ssrs_domain}" }
  },
  {
    "AppName": "PnxFolderWatcher",
    "RelativePath": "PnxFolderWatcher\\_Instances\\*\\KPI.Phoenix.FolderWatcherSvc.exe.config",
    "Settings": { "InterfaceID": "IRPT", "FolderWatchPath": "{drive}\\Program Files\\ProPhoenix\\PnxFolderWatcher\\_Instances\\{sub_instance}\\Rpt\\GettxtFile", "ProcessedFilePath": "{drive}\\Program Files\\ProPhoenix\\PnxFolderWatcher\\_Instances\\{sub_instance}\\Rpt\\ProcessedRpt", "KPIAppBasePath": "{drive}\\Program Files\\ProPhoenix\\Police RMS" }
  },
  {
    "AppName": "E911 Server",
    "RelativePath": "E911 Server\\_Instances\\*\\KPI.Phoenix.E911ServerSvc.exe.config",
    "Settings": { "CADServer": "{Full_Hostname}", "CADServerPort": "8888", "CADE911ServerPort": "9998" }
  },
  {
    "AppName": "Device Notification Server",
    "RelativePath": "Phoenix Device Notification\\_Instances\\*\\KPI.Phoenix.DeviceNotificationSvc.exe.config",
    "Settings": { "DeviceAppMgrSvrIP": "{hostname}", "DeviceAppMgrSvrPort": "5555" }
  },
  {
    "AppName": "External Interface Server",
    "RelativePath": "External Interface Server\\_Instances\\*\\KPI.Phoenix.ExtInterfaceServerSvc.exe.config",
    "Settings": { "KPIExtWatchDir": "{drive}\\Program Files\\ProPhoenix\\Watch", "ESOResendData": "True" }
  },
  {
    "AppName": "NCIC Server",
    "RelativePath": "NCIC Server\\_Instances\\*\\KPI.Phoenix.NCICServerSvc.exe.config",
    "Settings": { "NCICStateServerIP": "{hostname}", "NCICStateServerPort": "5858", "InterfaceName": "NCIC" }
  },
  {
    "AppName": "NCIC State Server",
    "RelativePath": "NCIC State Server\\_Instances\\*\\KPI.Phoenix.NCICStateServerSvc.exe.config",
    "Settings": { "NCICServerPort": "6667", "NCICStateServerIP": "{hostname}", "NCICStateServerPort": "5858" }
  },
  {
    "AppName": "Phoenix CAD Live Streaming Service",
    "RelativePath": "Phoenix CAD Live Streaming Service\\_Instances\\*\\KPI.Phoenix.LiveStreaming.AzureServerSvc.exe.config",
    "Settings": { "CADServerIP": "{hostname}", "CADServerPort": "8888" }
  },
  {
    "AppName": "Report Server",
    "RelativePath": "Report Server\\web.config",
    "Settings": { "RptServer_UserName": "{ssrs_user}", "RptServer_Domain": "{ssrs_domain}" }
  },
   {
    "AppName": "Job Server",
    "RelativePath": "Job Server\\_Instances\\*\\KPI.Phoenix.JobSvc.exe.config",
    "Settings": { "RptServer_UserName": "{ssrs_user}", "RptServer_Domain": "{ssrs_domain}" }
  },
  {
    "AppName": "Police RMS",
    "RelativePath": "Police RMS\\web.config",
    "Settings": { "PnxPdfService": "https://{cert_name}/Phoenixpdfservice", "CSPSignatureService": "https://elink.prophoenix.com/esign/api", "AILicenseService": "https://crmws.prophoenix.com/PNXAIAPI" }
  },
  {
    "AppName": "Fire RMS",
    "RelativePath": "Fire RMS\\web.config",
    "Settings": { "PnxPdfService": "https://{cert_name}/Phoenixpdfservice", "CSPSignatureService": "https://elink.prophoenix.com/esign/api" }
  },
  {
    "AppName": "Internal Affairs",
    "RelativePath": "Internal Affairs\\web.config",
    "Settings": { "PnxPdfService": "https://{cert_name}/Phoenixpdfservice", "CSPSignatureService": "https://elink.prophoenix.com/esign/api" }
  },
  {
    "AppName": "WebService",
    "RelativePath": "WebService\\web.config",
    "Settings": { "xslPath": "{ReportServerPath}", "DeviceNotifySvrIP": "{hostname}", "DeviceNotificationSvrPort": "5555", "IsWCFChannelEnabled": "TRUE" }
  },
  {
    "AppName": "Phoenix Report Writer API",
    "RelativePath": "Phoenix Report Writer API\\appsettings.json",
    "Settings": { "JwtExpireDays": 30, "TemplatePath": "{drive}\\Program Files\\ProPhoenix\\Report Server\\Police\\Reports", "BasePath": "{drive}\\Program Files\\ProPhoenix\\Police RMS", "NIBRS_APIServ": "{hostname}/NibrsService/api/PnxNibrs/NibrsValidation" }
  }
]
"@

$appConfigs = $jsonConfig | ConvertFrom-Json
$hostname = [System.Net.Dns]::GetHostName()
$fullHostname = [System.Net.Dns]::GetHostEntry($hostname).HostName

$replacements = @{
    'hostname'      = $hostname
    'fullhostname'  = $fullHostname
    'full_hostname' = $fullHostname
    'cert_name'     = $certName
    'ssrs_user'     = $ssrsUser       
    'ssrs_domain'   = $ssrsDomain     
}
$keysToUseCertName = @("KPIRMSURL", "KPIFireRMSURL", "PnxPdfService")

function UpdateOrAddKey([xml]$xmlDoc, [System.Xml.XmlElement]$settingsNode, $key, $value, $subInstance) {
    $replacements['sub_instance'] = $subInstance
    $finalValue = $value
    foreach ($placeholder in $replacements.Keys) {
        if (($key -in $keysToUseCertName -and $placeholder -eq 'cert_name') -or ($key -notin $keysToUseCertName -and $placeholder -ne 'cert_name')) {
            $finalValue = $finalValue -replace "(?i)\{$placeholder\}", $replacements[$placeholder]
        }
    }
    $xpath = "*[local-name()='add' and (@key='$key' or @Key='$key')]"
    $node = $settingsNode.SelectSingleNode($xpath)
    if ($node) {
        if ($node.HasAttribute("Value")) { $node.SetAttribute("Value", $finalValue) } else { $node.SetAttribute("value", $finalValue) }
    } else {
        $newElem = $xmlDoc.CreateElement("add", $settingsNode.NamespaceURI)
        $newElem.SetAttribute("key", $key)
        $newElem.SetAttribute("value", $finalValue)
        $settingsNode.AppendChild($newElem) | Out-Null
    }
}

foreach ($app in $appConfigs) {
    Write-Host "`n  -> Processing: $($app.AppName)" -ForegroundColor Gray
    
    $searchPattern = Join-Path $PnxInstallPath ($app.RelativePath -replace '\\', [IO.Path]::DirectorySeparatorChar)
    $matchedFiles = Get-ChildItem -Path $searchPattern -File -ErrorAction SilentlyContinue
    
    if (-not $matchedFiles) {
        Write-Host "     [SKIP] No configuration files found." -ForegroundColor DarkYellow
        continue
    }

    foreach ($configFile in $matchedFiles) {
        $subInstance = $configFile.Directory.Name
        $replacements['sub_instance'] = $subInstance
        $replacements['drive'] = ($configFile.Directory.Root.FullName).TrimEnd('\')
        $replacements['reportserverpath'] = Join-Path $replacements['drive'] "Program Files\ProPhoenix\Report Server"

        $extension = $configFile.Extension.ToLower()
        Write-Host "     [FILE] Updating: $($configFile.Name)" -ForegroundColor DarkGray
        
        # Path Creation logic within JSON values
        foreach ($kv in $app.Settings.PSObject.Properties) {
            if ($kv.Name -match 'Path$') {
                $resolvedPath = $kv.Value
                foreach ($p in @('drive', 'sub_instance')) { $resolvedPath = $resolvedPath -replace "(?i)\{$p\}", $replacements[$p] }
                if (-not (Test-Path $resolvedPath)) { try { New-Item -Path $resolvedPath -ItemType Directory -Force | Out-Null } catch {} }
            }
        }

        try {
            if ($extension -eq '.json') {
                $fileContent = [System.IO.File]::ReadAllText($configFile.FullName)
                $jsonObj = $fileContent | ConvertFrom-Json
                $targetObj = if ($null -ne $jsonObj.PSObject.Properties['AppSettings']) { $jsonObj.AppSettings } else { $jsonObj }

                foreach ($kv in $app.Settings.PSObject.Properties) {
                    $key = $kv.Name; $val = $kv.Value
                    if ($val -is [string]) { foreach ($p in $replacements.Keys) { $val = $val -replace "(?i)\{$p\}", $replacements[$p] } }
                    if ($null -ne $targetObj.PSObject.Properties[$key]) { $targetObj.$key = $val } else { $targetObj | Add-Member -MemberType NoteProperty -Name $key -Value $val }
                    Write-Host "        -> Updated JSON key: $key" -ForegroundColor DarkGray
                }
                $jsonString = $jsonObj | ConvertTo-Json -Depth 10
                [System.IO.File]::WriteAllText($configFile.FullName, $jsonString)
            }
            elseif ($extension -eq '.config') {
                $fileContent = [System.IO.File]::ReadAllText($configFile.FullName)
                [xml]$xml = $fileContent
                $configNode = $xml.SelectSingleNode("//*[local-name()='configuration']")
                if (-not $configNode) { $configNode = $xml.SelectSingleNode("//*[local-name()='Configuration']") }

                if ($configNode) {
                    $appSettings = $configNode.SelectSingleNode("*[local-name()='appSettings']")
                    if (-not $appSettings) {
                        $appSettings = $xml.CreateElement("appSettings", $configNode.NamespaceURI)
                        $configNode.AppendChild($appSettings) | Out-Null
                    }
                    foreach ($kv in $app.Settings.PSObject.Properties) {
                        UpdateOrAddKey -xmlDoc $xml -settingsNode $appSettings -key $kv.Name -value $kv.Value -subInstance $subInstance
                        Write-Host "        -> Updated XML key: $($kv.Name)" -ForegroundColor DarkGray
                    }
                    $xml.Save($configFile.FullName)
                }
            }
        } catch { Write-Host "     [FAIL] FAILED on file: $($configFile.FullName)" -ForegroundColor Red }
    }
}

Write-Host " -> Status: COMPLETED" -ForegroundColor Green

Write-Host "`n======================================================" -ForegroundColor Cyan
Write-Host " MASTER PROVISIONING COMPLETE" -ForegroundColor Green
Write-Host "======================================================" -ForegroundColor Cyan

Read-Host -Prompt "Press Enter to close the terminal"
[Environment]::Exit(0)